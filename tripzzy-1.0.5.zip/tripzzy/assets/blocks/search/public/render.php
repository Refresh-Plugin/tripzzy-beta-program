<?php
/**
 * Tripzzy Render Search Form.
 *
 * @since 1.0.0
 * @since 1.0.5 API updated to v3 and settings. Wrapper div element with class 'tripzzy-trip-search-block' added.
 * @package tripzzy
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
use Tripzzy\Core\Template;
use Tripzzy\Core\Helpers\ArrayHelper;
use Tripzzy\Core\Assets;
use Tripzzy\Core\Blocks;
$layout     = $attributes['layout'] ?? 'row';
$class_name = 'column' === $layout ? 'tripzzy-trip-search-block column-view' : 'tripzzy-trip-search-block';

// Container Styles.
$container_width = $attributes['container_width'] ?? '100%';
$gap             = $attributes['gap'] ?? '0';
$backgrond_color = Blocks::get_background_color( $attributes );
$text_color      = Blocks::get_text_color( $attributes );
$font_size       = Blocks::get_font_size( $attributes );

$styles = array(
	array(
		'selector' => '.tripzzy-trip-search-block',
		'css'      => array(
			'width'      => $container_width,
			'background' => $backgrond_color,
		),
	),
	array(
		'selector' => '.tripzzy-trip-search form .tripzzy-advanced-search-form',
		'css'      => array( 'gap' => $gap ),
	),
	array(
		'selector' => '.tripzzy-trip-search form input,
		.tripzzy-trip-search form select,
		.tripzzy-trip-search form .tripzzy-before-field i',
		'css'      => array( 'font-size' => $font_size ),
	),
	array(
		'selector' => '.tripzzy-trip-search form input,
		.tripzzy-trip-search form select',
		'css'      => array( 'padding-left' => 'calc( ' . $font_size . ' + 20px) !important' ),
	),
	array(
		'selector' => '.tripzzy-trip-search form .tripzzy-advanced-search-form .tripzzy-form-field.has-before-field .tripzzy-before-field i,
		.tripzzy-trip-search form .tripzzy-advanced-search-form select',
		'css'      => array( 'color' => $text_color ),
	),
	array(
		'selector' => '.tripzzy-trip-search form .tripzzy-advanced-search-form input[type="submit"]',
		'css'      => array(
			'color'      => $attributes['buttonColor'] ?? '',
			'background' => $attributes['buttonBackgroundColor'] ?? '',
		),
	),
	array(
		'selector' => '.tripzzy-trip-search form .tripzzy-advanced-search-form input[type="submit"]:hover',
		'css'      => array(
			'color'      => $attributes['buttonColorHover'] ?? '',
			'background' => $attributes['buttonBackgroundColorHover'] ?? '',
		),
	),
);
// Need to enqueue as inline style later.
?>
<style>
	<?php echo wp_kses_post( Assets::array_to_css( $styles ) ); ?>
</style>
<div class="<?php echo esc_attr( $class_name ); ?>">
	<?php Template::get_template( 'trip-search', $attributes ); ?>
</div>
