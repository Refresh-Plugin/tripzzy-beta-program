<?php
/**
 * Views: Homepage.
 *
 * @package tripzzy
 */

namespace Tripzzy\Admin\Views;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
use Tripzzy\Core\Helpers\Loading;

if ( ! class_exists( 'Tripzzy\Admin\Views\HomepageView' ) ) {
	/**
	 * HomepageView Class.
	 *
	 * @since 1.0.0
	 */
	class HomepageView {

		/**
		 * Home page html.
		 *
		 * @since 1.0.0
		 */
		public static function render() {
			?>
			<div class="tripzzy-home-page-wrapper">
				<div id="tripzzy-home-page" class="tripzzy-page tripzzy-home-page">
					<?php Loading::render(); ?>
				</div>
			</div>
			<?php
		}
	}
}
