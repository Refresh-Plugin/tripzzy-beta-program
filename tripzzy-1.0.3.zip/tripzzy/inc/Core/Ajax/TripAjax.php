<?php
/**
 * Trip ajax class.
 *
 * @package tripzzy
 */

namespace Tripzzy\Core\Ajax;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
use Tripzzy\Core\Traits\SingletonTrait;
use Tripzzy\Core\Http\Nonce;
use Tripzzy\Core\Http\Request;
use Tripzzy\Core\Template;
use Tripzzy\Core\Bases\TaxonomyBase;
use Tripzzy\Core\Helpers\Trip;
use Tripzzy\Core\Helpers\Strings;
use Tripzzy\Core\Helpers\FilterPlus;
use Tripzzy\Core\Helpers\Cookie;
use Tripzzy\Core\Helpers\Amount;
use Tripzzy\Core\Helpers\MetaHelpers;

if ( ! class_exists( 'Tripzzy\Core\Ajax\TripAjax' ) ) {
	/**
	 * Trip Ajax class.
	 *
	 * @since 1.0.0
	 */
	class TripAjax {
		use SingletonTrait;

		/**
		 * All available messages.
		 *
		 * @var array
		 */
		private $messages;
		/**
		 * All available labels.
		 *
		 * @var array
		 */
		private $labels;


		/**
		 * Constructor.
		 */
		public function __construct() {
			$this->messages = Strings::messages();
			$this->labels   = Strings::labels();
			// Admin side Ajax.
			add_action( 'wp_ajax_tripzzy_get_trip', array( $this, 'get' ) );
			add_action( 'wp_ajax_tripzzy_update_trip', array( $this, 'update' ) );
			add_action( 'wp_ajax_tripzzy_check_trip_code_exist', array( $this, 'check_trip_code_exist' ) );

			// Frontend side Ajax.
			// Archive page list trip.
			add_action( 'wp_ajax_nopriv_tripzzy_get_trips', array( $this, 'render_trips' ) );
			add_action( 'wp_ajax_tripzzy_get_trips', array( $this, 'render_trips' ) );

			// Archive page set view mode.
			add_action( 'wp_ajax_nopriv_tripzzy_set_view_mode', array( $this, 'set_view_mode' ) );
			add_action( 'wp_ajax_tripzzy_set_view_mode', array( $this, 'set_view_mode' ) );

			// List trip available Dates.
			add_action( 'wp_ajax_nopriv_tripzzy_render_trip_dates', array( $this, 'render_trip_dates' ) );
			add_action( 'wp_ajax_tripzzy_render_trip_dates', array( $this, 'render_trip_dates' ) );

			// Change Package category as per package id provided.
			add_action( 'wp_ajax_nopriv_tripzzy_get_package_categories', array( $this, 'render_package_categories' ) );
			add_action( 'wp_ajax_tripzzy_get_package_categories', array( $this, 'render_package_categories' ) );

			// Set Featured trip.
			add_action( 'wp_ajax_tripzzy_set_featured_trip', array( $this, 'set_featured_trip' ) );
		}

		/**
		 * Ajax callback to get trip data.
		 *
		 * @since 1.0.0
		 */
		public function get() {
			if ( ! Nonce::verify() ) {
				$message = array( 'message' => $this->messages['nonce_verification_failed'] );
				wp_send_json_error( $message );
			}

			// Nonce already verified using Nonce::verify method.
			$trip_id = isset( $_GET['trip_id'] ) ? absint( $_GET['trip_id'] ) : ''; // @codingStandardsIgnoreLine

			$response_data = Trip::get( $trip_id );
			$response      = array(
				'trip' => $response_data,
			);
			wp_send_json_success( $response, 200 );
		}

		/**
		 * Ajax callback to set form data.
		 *
		 * @since 1.0.0
		 */
		public function update() {
			if ( ! Nonce::verify() ) {
				$message = array( 'message' => $this->messages['nonce_verification_failed'] );
				wp_send_json_error( $message );
			}

			$trip_id       = isset( $_GET['trip_id'] ) ? absint( $_GET['trip_id'] ) : 0; // @codingStandardsIgnoreLine
			$response_data = Trip::update( $trip_id );
			if ( $trip_id && $response_data ) {
				wp_send_json_success( $response_data, 200 );
			}
		}

		/**
		 * Check Trip code exists.
		 *
		 * @since 1.0.0
		 */
		public function check_trip_code_exist() {
			if ( ! Nonce::verify() ) {
				$message = array( 'message' => $this->messages['nonce_verification_failed'] );
				wp_send_json_error( $message );
			}
			// Nonce already verified using Nonce::verify method.
			$trip_id   = isset( $_GET['trip_id'] ) ? absint( $_GET['trip_id'] ) : 0; // @codingStandardsIgnoreLine
			$trip_code = isset( $_GET['trip_code'] ) ? sanitize_text_field( wp_unslash( $_GET['trip_code'] ) ) : ''; // @codingStandardsIgnoreLine
			$res       = Trip::get_trip_id_by_code( $trip_code );
			if ( ! $res || absint( $trip_id ) === absint( $res ) ) { // If empty or current post=response post.
				// Check if trip code consist another trip/post id.
				$temp_data = explode( '-', $trip_code );
				if ( count( $temp_data ) > 1 ) {
					$temp_trip_id   = (int) $temp_data[1];
					$temp_trip_code = Trip::get_code( $temp_trip_id );
					if ( (int) $trip_id !== (int) $temp_trip_id && $trip_code === $temp_trip_code ) {
						wp_send_json_error( $trip_code );
					}
				}
				wp_send_json_success( $trip_code );
			}
			wp_send_json_error( $trip_code );
		}

		/**
		 * Ajax Callback to render all trips with Markups. Need To move logic in helper file.
		 */
		public function render_trips() {
			if ( ! Nonce::verify() ) {
				$message = array(
					'message' => $this->messages['nonce_verification_failed'],
				);
				wp_send_json_error( $message );
			}

			$data  = Request::get_payload();
			$paged = isset( $data['paged'] ) ? $data['paged'] : 1;
			$args  = array(
				'post_type'   => 'tripzzy',
				'paged'       => $paged,
				'post_status' => array( 'publish' ),
			);

			if ( $data ) {
				$args['tax_query']['relation'] = 'AND';

				$taxonomies = TaxonomyBase::get_args();
				foreach ( $taxonomies as $taxonomy => $taxonomy_args ) {
					if ( isset( $data[ $taxonomy ] ) && ! empty( $data[ $taxonomy ] ) ) {
						if ( is_array( $data[ $taxonomy ] ) ) {
							// Filter empty value from the taxonomy list to perform tax query.
							$terms = array_filter(
								$data[ $taxonomy ],
								function ( $value ) {
									return ! empty( $value );
								}
							);
						} else {
							$terms = array( $data[ $taxonomy ] );
						}
						if ( ! empty( $terms ) ) {
							$args['tax_query'][] = array(
								'taxonomy' => $taxonomy,
								'field'    => 'slug',
								'terms'    => $terms,
							);
						}
					}
				}

				$custom_taxonomies = FilterPlus::get();
				if ( is_array( $custom_taxonomies ) && count( $custom_taxonomies ) > 0 ) {
					foreach ( $custom_taxonomies as $slug => $custom_taxonomy ) {
						if ( isset( $data[ $slug ] ) && ! empty( $data[ $slug ] ) ) {
							$args['tax_query'][] = array(
								'taxonomy' => $slug,
								'field'    => 'slug',
								'terms'    => is_array( $data[ $slug ] ) ? $data[ $slug ] : array( $data[ $slug ] ),
							);
						}
					}
				}
			}

			ob_start();

			$query = new \WP_Query( $args );

			while ( $query->have_posts() ) {
				$query->the_post();
				Template::get_template_part( 'content', 'archive-tripzzy' );
			}
			$found_posts      = $query->found_posts;
			$found_posts_html = '';

			wp_reset_postdata();
			$trips = ob_get_clean();

			if ( $found_posts > 0 ) {
				/*
				 * Translators: %s Found Posts.
				 */
				$found_posts_html = sprintf( _n( '%s trip found.', '%s trips found.', $found_posts, 'tripzzy' ), number_format_i18n( $found_posts ) );
			}

			if ( ! $trips ) {
				ob_start();
				?>
				<article><p><?php esc_html_e( 'No trips found.', 'tripzzy' ); ?></p></article>
				<?php
				$trips = ob_get_clean();
			}
			$response = array(
				'trips'            => $trips,
				'found_posts_html' => $found_posts_html,
				'found_posts'      => $found_posts,
				'paged'            => $paged,
				'max_num_pages'    => $query->max_num_pages,
			);
			wp_send_json_success( $response );
		}

		/**
		 * Render Trip Dates.
		 *
		 * @return void
		 */
		public function render_trip_dates() {
			if ( ! Nonce::verify() ) {
				$message = array(
					'message' => $this->messages['nonce_verification_failed'],
				);
				wp_send_json_error( $message );
			}
			ob_start();
			$data    = Request::get_payload();
			$trip_id = $data['trip_id'];
			$trip    = new Trip( $trip_id );

			$packages  = $trip->packages();
			$package   = $packages->get_package();
			$category  = $package ? $package->get_category() : null;
			$price     = $category ? $category->get_price() : 0;
			$price_per = $trip->get_price_per();

			$dates      = $trip->dates();
			$trip_dates = $dates->get_dates();
			foreach ( $trip_dates as $trip_date ) :
				$start_date   = $trip_date['start_date'];
				$end_date     = isset( $trip_date['end_date'] ) && is_a( $trip_date['end_date'], '\Carbon\Carbon' ) ? $trip_date['end_date'] : false;
				$booking_data = array(
					'trip_id'    => $trip_id,
					'start_date' => $start_date->format( 'Y-m-d' ),
				);
				?>
				<div class="tripzzy-dates-content" data-trip-booking='<?php echo esc_attr( wp_json_encode( $booking_data ) ); ?>'> <!-- Repeator -->
					<ul>
						<li>
							<span class="label"><?php echo esc_html( $this->labels['from'] ?? 'From' ); ?></span>
							<strong><?php echo esc_html( $start_date->format( 'j F Y' ) ); ?></strong>
						</li>
						<?php if ( $end_date ) : ?>
							<li>
								<span class="label">To</span>
								<strong><?php echo esc_html( $end_date->format( 'j F Y' ) ); ?></strong>
							</li>
						<?php endif; ?>
						<li>
							<span class="label"><?php echo esc_html( $this->labels['from'] ?? 'From' ); ?></span>
							<strong class="tz-departure-list-from-price"><?php echo esc_html( \Tripzzy\Core\Helpers\Amount::display( $price ) ); ?></strong><span> / <?php echo esc_html( $price_per ); ?></span>
						</li>
						<li>
							<div class="tz-departure-list-book-now">
								<a href="#" class="tripzzy__booking-button tz-btn tz-btn-outline tz-btn-full" data-booknow-text="<?php echo esc_attr_x( 'Book Now', 'Display Price Category for checkout.', 'tripzzy' ); ?>" data-alt-text=<?php echo esc_attr_x( 'Cancel', 'Booking cancel button.', 'tripzzy' ); ?> data-trip-booking-btn><?php echo esc_attr_x( 'Book Now', 'Book Now Button', 'tripzzy' ); ?></a>
							</div>
						</li>
					</ul>

					<div class="tripzzy__booking-categories-wrapper hidden" data-trip-booking-categories></div>
				</div>
				<?php
			endforeach;
			$content = ob_get_contents();
			ob_end_clean();

			$response = array(
				'dates'             => $content,
				'next_start_date'   => $dates->next_start_date, // for recurring date.
				'date_limit_exceed' => $dates->date_limit_exceed, // For recurring date.
				'pagination'        => $dates->pagination, // For fixed departure date.
			);
			wp_send_json_success( $response );
		}

		/**
		 * Render package categories as per package id.
		 *
		 * @return void
		 */
		public function render_package_categories() {
			if ( ! Nonce::verify() ) {
				$message = array(
					'message' => $this->messages['nonce_verification_failed'],
				);
				wp_send_json_error( $message );
			}
			ob_start();
			$data = Request::get_payload();

			$trip_id    = $data['trip_id'];
			$package_id = $data['package_id'];
			$trip       = new Trip( $trip_id );

			$price_per_key = $trip->price_per;
			$packages      = $trip->packages();
			$package       = $packages->get_package( $package_id );
			$categories    = $package ? $package->get_categories() : null;

			// Display From price.
			$category   = $package->get_category();
			$from_price = 0;
			if ( $category ) {
				$from_price = $category->get_price();
			}

			foreach ( $categories as $package_category ) {
				$package_category_id = $package_category->get_id();
				if ( ! get_term( $package_category_id ) ) {
					continue;
				}

				?>
				<div class="tripzzy__category-item" style="display:flex;justify-content:space-between;">
					<div class="tripzzy__category-title">
						<?php echo esc_html( $package_category->get_title() ); ?>
					</div>
					<div class="tripzzy__category-counter">
						<span class="qty">Qty:</span>
						<input min="0" type="number" data-category-counter="<?php echo absint( $package_category_id ); ?>"/>
					</div>
					<?php if ( 'person' === $price_per_key ) : ?>
						<div class="tripzzy__category-price">
							<?php
							if ( $package_category->get_sale_price() ) {
								?>
								<del><?php echo esc_html( \Tripzzy\Core\Helpers\Amount::display( $package_category->get_regular_price() ) ); ?></del>
								<?php echo esc_html( \Tripzzy\Core\Helpers\Amount::display( $package_category->get_price() ) ); ?>
								<?php
							} else {
								echo esc_html( \Tripzzy\Core\Helpers\Amount::display( $package_category->get_price() ) );
							}
							?>
						</div>
					<?php endif; ?>
				</div>
				<?php
			}

			$content = ob_get_contents();
			ob_end_clean();

			$response = array(
				'categories' => $content,
				'from_price' => \Tripzzy\Core\Helpers\Amount::display( $from_price ),
			);
			wp_send_json_success( $response );
		}

		/**
		 * Set View Mode.
		 */
		public function set_view_mode() {
			if ( ! Nonce::verify() ) {
				$message = array( 'message' => $this->messages['nonce_verification_failed'] );
				wp_send_json_error( $message );
			}
			// Nonce already verified using Nonce::verify method.
			$view_mode = isset( $_POST['view_mode'] ) ? sanitize_text_field( wp_unslash( $_POST['view_mode'] ) ) : 'list'; // @codingStandardsIgnoreLine
			Cookie::set( 'view_mode', $view_mode );
		}

		/**
		 * Set Featured Trip.
		 */
		public function set_featured_trip() {
			if ( ! Nonce::verify() ) {
				$message = array(
					'message' => $this->messages['nonce_verification_failed'],
				);
				wp_send_json_error( $message );
			}

			$data    = Request::get_payload();
			$trip_id = $data['trip_id'];
			$trip    = new Trip( $trip_id );

			$is_featured = $trip->is_featured();

			MetaHelpers::update_post_meta( $trip_id, 'featured', ! $is_featured );
			$response = array( 'trip_id' => $trip_id );
			wp_send_json_success( $response );
		}
	}

	TripAjax::instance();
}
