<?php
/**
 * Tripzzy Trips.
 *
 * @since 1.0.1
 * @package tripzzy
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use Tripzzy\Core\Image;
use Tripzzy\Core\Helpers\MetaHelpers;

$data          = $attributes['query'] ?? array();
$tripzzy_terms = get_terms(
	array(
		'taxonomy'   => $data['taxonomy'] ?? 'tripzzy_trip_destination',
		'orderby'    => $data['orderBy'] ?? 'name',
		'order'      => $data['order'] ?? 'asc',
		'number'     => $data['numberOfItems'] ?? 4,
		'hide_empty' => false,
	)
);
?>
<div class="tripzzy-trip-categories" >
	<div class="tz-row tripzzy-trip-category-listings">
		<?php if ( is_array( $tripzzy_terms ) && count( $tripzzy_terms ) > 0 ) : ?>
			<?php
			foreach ( $tripzzy_terms as $tripzzy_term ) :
				/* translators: %d Term count */
				$term_count    = sprintf( _n( '%d trip', '%d trips', $tripzzy_term->count, 'tripzzy' ), $tripzzy_term->count );
				$thumbnail_url = MetaHelpers::get_term_meta( $tripzzy_term->term_id, 'taxonomy_image_url' );
				if ( ! $thumbnail_url ) {
					$thumbnail_url = Image::default_thumbnail_url();
				}
				?>
				<div class="tz-col">
					<div class="tripzzy-trip-category">
						<div class="tripzzy-trip-category-img">
							<img src="<?php echo esc_url( $thumbnail_url ); ?>" />
							<h3 class="tripzzy-trip-category-title tripzzy-trip-category-bottom-content">
								<a href="<?php echo esc_url( get_term_link( $tripzzy_term->term_id ) ); ?>">
									<?php echo esc_html( $tripzzy_term->name ); ?>
									<span class="tripzzy-trip-category-count" >
										<?php echo esc_html( $term_count ); ?>
									</span>
								</a>
							</h3>
						</div>
					</div>
				</div>
			<?php endforeach; ?>	
		<?php endif; ?>
	</div>
</div>
