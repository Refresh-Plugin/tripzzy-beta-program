<?php
/**
 * Tripzzy Trips.
 *
 * @package tripzzy
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use Tripzzy\Core\Image;
use Tripzzy\Core\Helpers\Trip;
use Tripzzy\Core\Helpers\Amount;
use Tripzzy\Core\Helpers\Reviews;
use Tripzzy\Core\Helpers\Strings;

$trips             = $attributes['trips'] ?? array();
$tripzzy_logged_in = is_user_logged_in();
$tripzzy_view_mode = $attributes['view_mode'] ?? 'grid_view';

$images_url = sprintf( '%sassets/images', esc_url( TRIPZZY_PLUGIN_DIR_URL ) );
$labels     = Strings::get()['labels'];
if ( count( $trips ) > 0 ) : ?>
	<div class="tripzzy-trips <?php echo esc_attr( $tripzzy_view_mode ); ?>-view">
		<div class="tz-row tripzzy-trip-listings">
			<?php
			foreach ( $trips as $trip ) :
				// variables.
				$trip_id                  = $trip['id'];
				$tripzzy_thumbnail_url    = $trip['tripzzy_thumbnail_url'] ?? '';
				$tripzzy_is_featured      = $trip['tripzzy_is_featured'] ?? false;
				$tripzzy_has_sale         = $trip['tripzzy_has_sale'] ?? false;
				$tripzzy_sale_percent     = $trip['tripzzy_sale_percent'] ?? 0;
				$tripzzy_thumbnail_url    = $trip['tripzzy_thumbnail_url'] ?? '';
				$tripzzy_in_wishlists     = Trip::in_wishlists( $trip_id );
				$tripzzy_regular_price    = $trip['tripzzy_regular_price'] ?? 0;
				$tripzzy_price            = $trip['tripzzy_price'] ?? 0;
				$tripzzy_tax_destination  = $trip['tripzzy_tax_destination'] ?? array();
				$tripzzy_trip_duration    = $trip['tripzzy_trip_duration'] ?? array();
				$tripzzy_has_difficulties = $trip['tripzzy_has_difficulties'] ?? false;
				$tripzzy_difficulty       = $trip['tripzzy_difficulty'] ?? 'N/A';



				$tripzzy_wishlist_button_attr  = ! $tripzzy_logged_in ? 'disabled' : '';
				$tripzzy_wishlist_button_title = ! $tripzzy_logged_in ? 'Please login to add your wishlists.' : 'Please click to add your wishlists';

				?>
				<div class="tz-col">
					<article class="">
					<div class="tripzzy-trip">
						<div class="tz-row">
						<div class="tz-col tz-cols-4-md">
							<div class="tripzzy-thumbnail">
							<a href="<?php echo esc_url( get_the_permalink( $trip_id ) ); ?>">
								<?php Image::get_thumbnail( $trip_id ); ?>
							</a>
							<div class="tripzzy-wishlist">
								<button <?php echo esc_attr( $tripzzy_wishlist_button_attr ); ?>
									title="<?php echo esc_attr( $tripzzy_wishlist_button_title ); ?>"
									class="tripzzy-wishlist-button  <?php echo esc_attr( $tripzzy_in_wishlists ? 'in-list' : '' ); ?>"
									data-trip-id="<?php esc_attr( $trip_id ); ?>"><i class="<?php echo esc_attr( $tripzzy_in_wishlists ? 'fa-solid' : 'fa-regular' ); ?> fa-heart"></i></button>
							</div>
							<div class="tripzzy-ribbon-group vertical">
								<?php if ( $tripzzy_is_featured ) : ?>
									<div class="tripzzy-ribbon ribbon-featured">
										<span class="tripzzy-ribbon-text">
										Featured
										</span>
									</div>
								<?php endif; ?>
								<?php if ( $tripzzy_has_sale ) : ?>
									<div class="tripzzy-ribbon ribbon-discount">
										<span class="tripzzy-ribbon-text">
										-<?php echo esc_html( $tripzzy_sale_percent ); ?>%
										</span>
									</div>
								<?php endif; ?>
							</div>
							</div>
						</div>
						<div class="tz-col tz-cols-8-md">
							<div class="tripzzy-content-wrapper">
							<div class="tripzzy-trip-price">
								<div class="tripzzy-price-wrapper">
									<?php if ( $tripzzy_has_sale ) : ?>
										<div class="tripzzy-regular-price">
											<?php echo esc_html( Amount::display( $tripzzy_regular_price ) ); ?>
										</div>
									<?php endif; ?>
									<div class="tripzzy-price">
										<?php echo esc_html( Amount::display( $tripzzy_price ) ); ?>
									</div>
								</div>
							</div>
							<h3 class="tripzzy-trip-title">
								<a href="<?php echo esc_url( get_the_permalink( $trip_id ) ); ?>"><?php echo esc_html( get_the_title( $trip_id ) ); ?></a>
							</h3>
							<div class="tripzzy-after-title">
								<div class="tripzzy-review-wrapper">
								<?php Reviews::ratings_average_html( Reviews::get_trip_ratings_average( $trip_id ) ); ?>
								</div>
								<div class="tripzzy-meta-container">
								<div class="tripzzy-meta-wrapper">
									<div class="tripzzy-meta-item">
									<span
										class="tripzzy-meta destination"
										title="Destination"
									>
										<svg class="icon">
											<use xlink:href="<?php echo esc_url( $images_url ); ?>/sprite.svg#Pin_light" ></use>
										</svg>
										<span>
											<?php if ( count( $tripzzy_tax_destination ) > 0 ) : ?>
												<?php
												foreach ( $tripzzy_tax_destination as $destination ) :
													// Taxonomy is in array form here becasue the data saved from rest api.
													$destination_name = $destination['name'];
													$destination_link = get_term_link( $destination['term_id'] );
													?>
													<a href="<?php echo esc_url( $destination_link, 'tripzzy' ); ?>">
														<?php echo esc_html( $destination_name ); ?>
													</a>
												<?php endforeach; ?>
											<?php else : ?>
												<?php echo esc_html( $labels['na'] ?? '' ); ?>
											<?php endif; ?>
										</span>
									</span>
									</div>
								</div>
								</div>
							</div>
							<hr class="tripzzy-divider" />
							<div class="tripzzy-before-content">
								<div class="tripzzy-meta-container">
								<div class="tripzzy-meta-wrapper">
									<?php
										$duration_value = $tripzzy_trip_duration['duration'];
										$duration_unit  = $tripzzy_trip_duration['duration_unit'];
									?>
									<div class="tripzzy-meta-item">
									<span
										class="tripzzy-meta duration"
										title="Trip duration"
									>
										<svg class="icon">
											<use xlink:href="<?php echo esc_url( $images_url ); ?>/sprite.svg#Alarmclock_light" ></use>
										</svg>
										<span>
											<?php
											if ( is_array( $duration_value ) && isset( $duration_value[0] ) && absint( $duration_value[0] ) > 0 ) :
												printf( '%s %s', esc_html( $duration_value[0] ), esc_html( $duration_unit[0] ) );
											else :
												echo esc_html( $labels['na'] ?? '' );
											endif;
											?>
										</span>
									</span>
									</div>
									<?php if ( $tripzzy_has_difficulties ) : ?>
										<div class="tripzzy-meta-item">
											<span
											class="tripzzy-meta difficulty"
											title="Trip Difficulty"
											>
											<svg class="icon">
												<use xlink:href="<?php echo esc_url( $images_url ); ?>/sprite.svg#Waterfall_light" ></use>
											</svg>
											<span><?php echo esc_html( $tripzzy_difficulty ); ?></span>
											</span>
										</div>
									<?php endif; ?>
								</div>
								</div>
							</div>
							<div class="tripzzy-trip-button-wrapper">
								<a
								href="<?php echo esc_url( get_the_permalink( $trip_id ) ); ?>"
								class="tz-btn tz-btn-outline" >
									<?php echo esc_attr( $labels['view_details'] ?? '' ); ?>
								</a>
								<a
								href="<?php echo esc_url( get_the_permalink( $trip_id ) ); ?>#tripzzy-available-dates-section"
								class="tz-btn tz-btn-solid tm-book-now-btn"
								>
									<?php echo esc_attr( $labels['book_now'] ?? '' ); ?>
								</a>
							</div>
							</div>
						</div>
						</div>
					</div>
					</article>
				</div>
			<?php endforeach; ?>
		</div><!-- /.tripzzy-trip-listings -->
	</div><!-- /.tripzzy-trips -->
<?php endif; ?>
