<?php
/**
 * Tripzzy Admin Menu.
 *
 * @package tripzzy
 */

namespace Tripzzy\Admin;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
use Tripzzy\Core\Traits\SingletonTrait;
use Tripzzy\Core\Traits\AdminMenuTrait;

if ( ! class_exists( 'Tripzzy\Admin\AdminMenu' ) ) {
	/**
	 * Tripzzy Admin Menu Class.
	 *
	 * @since 1.0.0
	 */
	class AdminMenu {

		use SingletonTrait;
		use AdminMenuTrait;

		/**
		 * Constructor.
		 */
		public function __construct() {
			add_action( 'admin_menu', array( $this, 'init' ) );
		}
		/**
		 * Update the menu position, remove as per the arguments.
		 *
		 * @since 1.0.0
		 */
		public function init() {
			global $submenu;
			unset( $submenu['edit.php?post_type=tripzzy_booking'][10] ); // Removes 'Add New'.
			$all_submenus = self::get_submenus(); // Method from trait.

			foreach ( $all_submenus as $parent_slug => $sub_menus ) {
				foreach ( $sub_menus as $sub_menu ) {
					if ( ! isset( $sub_menu['page_title'] ) || ! isset( $sub_menu['menu_title'] ) || ! isset( $sub_menu['menu_slug'] ) || ! isset( $sub_menu['callback'] ) ) {
						continue;
					}
					$capability = isset( $sub_menu['capability'] ) ? $sub_menu['capability'] : 'manage_options';
					add_submenu_page( $parent_slug, $sub_menu['page_title'], $sub_menu['menu_title'], $capability, $sub_menu['menu_slug'], $sub_menu['callback'] );
				}
			}

			// Add Page from sub menu.
			remove_submenu_page( 'edit.php?post_type=tripzzy_booking', 'tripzzy-system-info' );
		}
	}
}
