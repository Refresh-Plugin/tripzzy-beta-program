<?php
/**
 * Views: Header.
 *
 * @package tripzzy
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
use Tripzzy\Core\Http\Request;
use Tripzzy\Core\Helpers\Strings;
/**
 * Admin Header.
 *
 * @param string $title Header title.
 * @param string $type Category of the title.
 */
function tripzzy_get_admin_header( $title = '', $type = '' ) {
	global $pagenow, $post, $pagename;
	$title     = '';
	$type      = '';
	$labels    = Strings::get()['labels'];
	$post_type = '';
	if ( ! is_object( $post ) ) {
		$post_type = isset( $_GET['post_type'] ) ? sanitize_text_field( wp_unslash( $_GET['post_type'] ) ) : '';  // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	} else {
		$post_type = $post->post_type;
	}
	$page_name     = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';  // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$taxonomy_name = isset( $_GET['taxonomy'] ) ? sanitize_text_field( wp_unslash( $_GET['taxonomy'] ) ) : '';  // phpcs:ignore WordPress.Security.NonceVerification.Recommended

	$images_url     = sprintf( '%sassets/images', esc_url( TRIPZZY_PLUGIN_DIR_URL ) );
	$brand_logo_url = apply_filters( 'tripzzy_filter_admin_header_logo', sprintf( '%s/logo.svg', $images_url ) );

	if ( ! empty( $page_name ) ) {
		switch ( $page_name ) {
			case 'tripzzy-settings':
				$title = $labels['settings'] ?? '';
				break;
			case 'tripzzy-custom-categories': // custom filters.
				$title = $labels['custom_filters'] ?? '';
				break;
			case 'tripzzy-system-info':
				$title = $labels['system_status'] ?? '';
				break;
		}
	} elseif ( ! empty( $taxonomy_name ) ) {
		$taxonomy = get_taxonomy( $taxonomy_name );
		$title    = $taxonomy->label ?? '';

	} elseif ( ! empty( $post_type ) ) {
		$post_type_obj = get_post_type_object( $post_type );
		$title         = $post_type_obj->label;

		if ( 'post.php' === $pagenow || 'post-new.php' === $pagenow ) { // single page.
			$type  = $title;
			$title = get_the_title();
		}
	}
	?>
	<div class="tripzzy-page-header-container">
		<div class="tripzzy-page-header">
			<div class="tripzzy-header-info-left">
				<div class="tripzzy-breadcrumbs">
					<h2>
						<i class="dashicons dashicons-admin-home"></i>
						<span><span class="logo-initial">Trip</span>zzy</span> 
						<span class="sep">></span>
						<?php
						if ( $type ) {
							?>
							<span><?php echo esc_html( $type ); ?></span>
							<span class="sep">></span>
							<?php
						}
						?>
						<span class="tripzzy-title-main" id="tripzzy-title-main"><?php echo esc_html( $title ); ?></span>
					</h2>
				</div>
			</div>
			<div class="tripzzy-header-info-middle">
				<div class="tripzzy-brand-info">
					<img src="<?php echo esc_url( $brand_logo_url ); ?>" height="50" />
					<span class="version">(v<?php echo esc_html( TRIPZZY_VERSION ); ?>)</span> 
				</div>
			</div>
			<div class="tripzzy-header-info-right">
				<div class="tripzzy-header-link-container">
					<span class="tripzzy-header-links" >
						<a href="https://refreshthemes.com/docs/" target="_blank">
							<i class="fa-solid fa-file-lines"></i>
						</a>
						<span class="tripzzy-header-link-tooltip"><?php echo esc_html( $labels['documentation'] ?? '' ); ?></span>
					</span>
					<span class="tripzzy-header-links" >
						<a href="https://refreshthemes.com/support/plugins/tripzzy/" target="_blank">
							<i class="fa-solid fa-circle-question"></i>
						</a>
						<span class="tripzzy-header-link-tooltip"><?php echo esc_html( $labels['support'] ?? '' ); ?></span>
					</span>
					<span class="tripzzy-header-links" >
						<a href="edit.php?post_type=tripzzy_booking&page=tripzzy-system-info" target="_blank">
							<i class="fa-solid fa-lightbulb"></i>
						</a>
						<span class="tripzzy-header-link-tooltip"><?php echo esc_html( $labels['system_info'] ?? '' ); ?></span>
					</span>
				</div>
			</div>
		</div>
	</div>
	<?php
}
