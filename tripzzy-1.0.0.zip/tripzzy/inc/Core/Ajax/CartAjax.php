<?php
/**
 * Cart ajax class.
 *
 * @package tripzzy
 */

namespace Tripzzy\Core\Ajax;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
use Tripzzy\Core\Traits\SingletonTrait;
use Tripzzy\Core\Helpers\Strings;
use Tripzzy\Core\Helpers\Coupon;
use Tripzzy\Core\Helpers\Trip;
use Tripzzy\Core\Helpers\ErrorMessage;
use Tripzzy\Core\Helpers\Page;
use Tripzzy\Core\Http\Nonce;
use Tripzzy\Core\Http\Request;
use Tripzzy\Core\Cart;
use Tripzzy\Core\SessionHandler;

if ( ! class_exists( 'Tripzzy\Core\Ajax\CartAjax' ) ) {
	/**
	 * Cart Ajax.
	 *
	 * @since 1.0.0
	 */
	class CartAjax {
		use SingletonTrait;

		/**
		 * Constructor.
		 */
		public function __construct() {
			// Add.
			add_action( 'wp_ajax_tripzzy_add_to_cart', array( $this, 'add' ) );
			add_action( 'wp_ajax_nopriv_tripzzy_add_to_cart', array( $this, 'add' ) );

			// Remove.
			add_action( 'wp_ajax_tripzzy_remove_cart_item', array( $this, 'remove' ) );
			add_action( 'wp_ajax_nopriv_tripzzy_remove_cart_item', array( $this, 'remove' ) );
		}

		/**
		 * Get main instance of cart class.
		 *
		 * @return \Cart
		 */
		public function get_cart_instance() {
			$cart = tripzzy()->cart;

			if ( ! $cart || ! $cart instanceof Cart ) {
				$error_message = new \WP_Error( 'tripzzy_cart_error', __( 'Unable to retrieve cart.', 'tripzzy' ), 500 );
				wp_send_json_error( $error_message );
			}
			return $cart;
		}

		/**
		 * Validate Add to request cart.
		 *
		 * @param array $cart_data Cart Data.
		 * @return boolean
		 */
		protected function validate_cart_request( $cart_data ) {
			return ! ! $cart_data && isset( $cart_data['trip_id'] ) && isset( $cart_data['categories'] ) && array_sum( $cart_data['categories'] ) > 0;
		}

		/**
		 * Add to cart ajax action.
		 *
		 * @since 1.0.0
		 */
		public function add() {
			if ( ! Nonce::verify() ) {
				$error_message = ErrorMessage::get( 'nonce_verification_failed' );
				wp_send_json_error( $error_message );
			}

			$cart_data = Request::get( 'payload' );

			if ( ! $this->validate_cart_request( $cart_data ) ) {
				$error_message = ErrorMessage::get( 'invalid_cart_request' );
				wp_send_json_error( $error_message );
			}

			$trip_id  = $cart_data['trip_id'];
			$quantity = array_sum( $cart_data['categories'] );
			$cart     = $this->get_cart_instance();
			$cart_id  = $cart->add( $cart_data, $trip_id, $quantity );

			if ( ! $cart_id ) {
				$error_message = ErrorMessage::get( 'unable_to_add_cart_item' );
				wp_send_json_error( $error_message );
			}

			// Redirect after trip added to cart.
			$checkout_url = Page::get_url( 'checkout' );
			/**
			 * Flter the redirect url after add to cart.
			 *
			 * @since 1.0.0
			 */
			$checkout_url = apply_filters( 'tripzzy_filter_checkout_url', $checkout_url );

			$response_args = array(
				'cart_id'  => $cart_id,
				'message'  => __( 'Added to cart successfully.', 'tripzzy' ),
				'redirect' => $checkout_url,
			);

			wp_send_json_success( $response_args, 200 );
		}

		/**
		 * Remove from cart ajax action.
		 *
		 * @since 1.0.0
		 */
		public function remove() {
			if ( ! Nonce::verify() ) {
				$error_message = ErrorMessage::get( 'nonce_verification_failed' );
				wp_send_json_error( $error_message );
			}

			$cart_data = Request::get( 'payload' );

			$cart_id = $cart_data['cart_id'];
			$cart    = $this->get_cart_instance();
			$cart_id = $cart->remove( $cart_id );

			$response_args = array(
				'cart_id' => $cart_id,
				'message' => __( 'Remove from cart successfully.', 'tripzzy' ),
			);

			wp_send_json_success( $response_args, 200 );
		}
	}

	CartAjax::instance();
}
