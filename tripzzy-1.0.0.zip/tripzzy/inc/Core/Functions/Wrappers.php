<?php
/**
 * Wrapper functions for Tripzzy classes.
 *
 * @package tripzzy
 */

/**
 * Exit if accessed directly.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
