<?php
/**
 * Overridable pluggable functions for Tripzzy.
 *
 * @package tripzzy
 */

/**
 * Exit if accessed directly.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
