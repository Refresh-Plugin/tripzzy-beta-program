<?php
/**
 * Trips.
 *
 * @package tripzzy
 * @since 1.0.0
 */

namespace Tripzzy\Core\Helpers;

use Tripzzy\Core\Forms\Form;
use Tripzzy\Core\PostTypes\TripzzyPostType;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Tripzzy\Core\Helpers\SearchForm' ) ) {

	/**
	 * Our main helper class that provides.
	 *
	 * @since 1.0.0
	 */
	class SearchForm {

		/**
		 * Get search form fields.
		 *
		 * @since 1.0.0
		 */
		public static function get_fields() {
			$fields = array(
				'post_type'   =>
				array(
					'type'          => 'hidden',
					'label'         => '',
					'name'          => 'post_type',
					'id'            => 'tripzzy-post-type',
					'class'         => 'tripzzy-post_type',
					'placeholder'   => '',
					'required'      => true,
					'priority'      => 10,
					'value'         => TripzzyPostType::get_key(),
					// Additional configurations .
					'is_new'        => false,
					'is_default'    => true,
					'enabled'       => true,
					'force_enabled' => true,
				),
				'destination' =>
				array(
					'type'          => 'taxonomy_dropdown',
					'label'         => __( 'Destination', 'tripzzy' ),
					'name'          => 'tripzzy_trip_destination',
					'id'            => 'tripzzy_trip_destination',
					'class'         => 'tripzzy_trip_destination',
					'placeholder'   => __( 'Select Destination', 'tripzzy' ),
					'required'      => false,
					'priority'      => 30,
					'value'         => '',
					'taxonomy'      => 'tripzzy_trip_destination',
					'input_style'   => array( 'display' => 'none' ),
					// Additional configurations.
					'is_new'        => false,
					'is_default'    => true,
					'enabled'       => true,
					'force_enabled' => false,
					'before_field'  => '<i class="fa-solid fa-location-dot"></i>',
					'attributes'    => array(
						'multiple',
						'search' => 'true',
					),
				),
				'trip_type'   =>
				array(
					'type'          => 'taxonomy_dropdown',
					'label'         => __( 'Trip Type', 'tripzzy' ),
					'name'          => 'tripzzy_trip_type',
					'id'            => 'tripzzy_trip_type',
					'class'         => 'tripzzy_trip_type',
					'placeholder'   => __( 'Select Trip Type', 'tripzzy' ),
					'required'      => false,
					'priority'      => 20,
					'value'         => '',
					'taxonomy'      => 'tripzzy_trip_type',
					'input_style'   => array( 'display' => 'none' ),
					// Additional configurations.
					'is_new'        => false,
					'is_default'    => true,
					'enabled'       => true,
					'force_enabled' => false,
					'before_field'  => '<i class="fa-solid fa-suitcase-rolling"></i>',
					'attributes'    => array(
						'multiple',
						'search' => 'true',
					),
				),
				's'           =>
				array(
					'type'          => 'text',
					'label'         => __( 'Search', 'tripzzy' ),
					'name'          => 's',
					'id'            => 's',
					'class'         => 's',
					'placeholder'   => __( 'Search', 'tripzzy' ),
					'required'      => false,
					'priority'      => 20,
					'value'         => '',
					// Additional configurations.
					'is_new'        => false,
					'is_default'    => true,
					'enabled'       => true,
					'force_enabled' => false,
				),
			);
			return $fields;
		}

		/**
		 * Render search form Markup.
		 *
		 * @param array $args Form Arguments.
		 *
		 * @since 1.0.0
		 */
		public static function render( $args = array() ) {
			$fields = $args['fields'] ?? array();
			if ( empty( $fields ) ) {
				$fields = self::get_fields();
			}
			$form_args = array(
				'fields' => $fields,
			);

			?> 
			<form method="get" name="tripzzy_search" action="<?php echo esc_url( home_url( '/' ) ); ?>" >
				<div class="tripzzy-advanced-search-form">
					<?php Form::render( $form_args ); ?>
					<input type="submit" value="Search" class="tz-btn tz-btn-solid" />
				</div>
			</form>
			<?php
		}
	}
}
