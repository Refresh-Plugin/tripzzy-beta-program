<?php
/**
 * Trips.
 *
 * @package tripzzy
 * @since 1.0.0
 */

namespace Tripzzy\Core\Helpers;

use Tripzzy\Core\Helpers\Taxonomy;
use Tripzzy\Core\Helpers\FilterPlus;
use Tripzzy\Core\Helpers\Settings;
use Tripzzy\Core\Helpers\ArrayHelper;
use Tripzzy\Core\Helpers\Cookie;
use Tripzzy\Core\Bases\TaxonomyBase;
use Tripzzy\Core\Http\Request;
use Tripzzy\Core\Http\Nonce;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Tripzzy\Core\Helpers\TripFilter' ) ) {

	/**
	 * Our main helper class that provides.
	 *
	 * @since 1.0.0
	 */
	class TripFilter {

		/**
		 * Get All filters.
		 */
		public static function get() {
			$settings   = Settings::get();
			$defaults   = Settings::default_settings();
			$taxonomies = TaxonomyBase::get_args();

			$filters = self::taxonomy_filters();
			// add settings to show/hide filter.
			foreach ( $filters as $taxonomy => $taxonomy_args ) {

				if ( $taxonomy_args['custom'] ) { // Apply custom filter settings.
					if ( ! isset( $settings['filters']['custom'][ $taxonomy ] ) ) {
						$settings['filters']['custom'][ $taxonomy ] = $defaults['filters']['custom'][ $taxonomy ];
					}
					$show = $settings['filters']['custom'][ $taxonomy ]['show'];
				} else { // Apply default taxonomy filter settings.
					if ( ! isset( $settings['filters']['default'][ $taxonomy ] ) ) {
						$settings['filters']['default'][ $taxonomy ] = $defaults['filters']['default'][ $taxonomy ];
					}
					$show = $settings['filters']['default'][ $taxonomy ]['show'];
				}
				$filters[ $taxonomy ]['show'] = $show;
			}
			$filters = apply_filters( 'tripzzy_filter_trip_filters', $filters );
			return ArrayHelper::sort_by_priority( $filters ); // Sort array by priority.
		}

		/**
		 * Get view mode for archive page.
		 */
		public static function get_view_mode() {
			$default_view_mode = 'list';
			$default_view_mode = apply_filters( 'tripzzy_filter_default_view_mode', $default_view_mode );
			$view_mode         = $default_view_mode;
			if ( Cookie::get( 'view_mode' ) ) {
				return Cookie::get( 'view_mode' );
			}
			return $view_mode;
		}

		/**
		 * Check if it has active filter/s or not.
		 *
		 * @since 1.0.0
		 * @return bool
		 */
		public static function has_active_filters() {
			$filters = self::get();
			$active  = false;
			foreach ( $filters as $taxonomy => $filter ) {
				if ( $filter['show'] ) {
					$terms = Taxonomy::get_terms_hierarchy( $taxonomy );
					if ( count( $terms ) ) {
						$active = true;
						break;
					}
				}
			}
			return $active;
		}

		/**
		 * Check if it has active filter/s or not.
		 *
		 * @since 1.0.0
		 * @return bool
		 */
		public static function has_filter_button() {
			$settings = Settings::get();
			return $settings['show_filter_button'];
		}



		/**
		 * Render HTML for Taxonomies.
		 *
		 * @param string $taxonomy Taxonomy name.
		 * @param array  $filter Arguments.
		 * @since 1.0.0
		 */
		public static function taxonomies_render( $taxonomy, $filter ) {
			if ( ! $filter['show'] ) {
				return;
			}
			$label = isset( $filter['label'] ) ? $filter['label'] : __( 'Category', 'tripzzy' );
			$terms = Taxonomy::get_terms_hierarchy( $taxonomy );
			if ( ! count( $terms ) ) {
				return;
			}
			?>
			<div class="tz-filter-widget <?php echo esc_attr( $taxonomy ); ?>">
				<h3 class="tz-filter-widget-title"><?php echo esc_html( $label ); ?></h3>
				<div class="tz-filter-widget-content">
					<?php self::get_terms_markup( $terms, $taxonomy ); ?>
				</div>
			</div>

			<?php
		}

		/**
		 * Render Template markup for taxonomy including hierarchy.
		 *
		 * @param array  $terms List of term.
		 * @param string $taxonomy Taxonomy name.
		 * @param bool   $children Has children or not.
		 */
		public static function get_terms_markup( $terms, $taxonomy = null, $children = false ) {

			$parent_count = 0;
			if ( is_array( $terms ) && count( $terms ) > 0 ) :
				$selected_terms = self::get_requested_taxonomy_terms( $taxonomy );
				if ( ! $children ) {
					?>
					<select name="<?php echo esc_attr( $taxonomy ); ?>" id="<?php echo esc_attr( $taxonomy ); ?>" class="tripzzy-filter-dropdown" multiple search="true" style="display:none">
					<?php
				}
				foreach ( $terms as $term ) {
					$term_class = $children ? 'child-term' : '';
					?>
					<option value="<?php echo esc_attr( $term->slug ); ?>" class="<?php echo esc_attr( $term_class ); ?>" <?php echo esc_attr( in_array( $term->slug, $selected_terms, true ) ? 'selected' : '' ); ?> >
						<?php echo esc_attr( $term->name ); ?> (<?php echo esc_html( $term->count ); ?>)
					</option>
					<?php
					if ( is_array( $term->children ) && count( $term->children ) > 0 ) {
						$_children = array();
						foreach ( $term->children as $term_child ) {
							$_children[ $term_child->term_id ] = $term_child;
						}
						call_user_func( array( __CLASS__, __FUNCTION__ ), $_children, $taxonomy, true ); // recursion if has child.
					}
				}
				if ( ! $children ) {
					?>
					</select>
					<?php
				}
			endif;
		}


		/**
		 * Callback to render Trip Filter section with all the filters.
		 *
		 * @hooked tripzzy_archive_before_content
		 */
		public static function render_trip_filters() {
			$has_filter_button = self::has_filter_button();

			if ( self::has_active_filters() ) :
				?>
				<div class="tz-filter-widget-area">
					<div class="multiselect-dropdown-selected" id="dropdownSelected">
						<span>Selected</span>
					</div>
					<form id="tripzzy-filter-form" method="post">
						<div class="tz-filter-header">
							<h2 class="tz-filter-title">Filter By</h2>
							<button class="tz-btn tz-btn-sm tz-btn-reset" type="reset" style="display:none">Clear</button>
							<input type="hidden" name="paged" value='1' id='tripzzy-paged' /> 
							<input type="hidden" name="has_filter_button" class="tripzzy-has-filter-button" value="<?php echo esc_attr( $has_filter_button ); ?>" />
						</div>

						<div class="tz-filter-widget-container">
							<?php
							$tripzzy_filters = self::get();
							if ( is_array( $tripzzy_filters ) ) {
								foreach ( $tripzzy_filters as $tripzzy_filter_taxonomy => $tripzzy_filter ) {
									if ( $tripzzy_filter['show'] ) {
										call_user_func( $tripzzy_filter['callback'], $tripzzy_filter_taxonomy, $tripzzy_filter );
									}
								}
							}
							?>
							<?php if ( $has_filter_button ) : ?>
								<button type="submit" class="tz-btn tz-btn-solid w-full" id="tz-filter-form-submit-btn">Show</button>
							<?php endif; ?>
						</div>
					</form>
				</div>
				<?php
			endif;
		}

		/**
		 * All Taxonomy filters to add it in settings and filters as well.
		 *
		 * @since 1.0.0
		 */
		public static function taxonomy_filters() {
			$taxonomies = TaxonomyBase::get_args();

			$filters  = array();
			$priority = 10;
			foreach ( $taxonomies as $taxonomy => $taxonomy_args ) {
				$filters[ $taxonomy ] = array(
					'label'    => $taxonomy_args['labels']['name'],
					'callback' => array( __CLASS__, 'taxonomies_render' ),
					'custom'   => false, // whether custom filters or not.
					'type'     => 'taxonomy', // To make all taxonomy filter as query args automatically.
					'priority' => $priority,
				);
				$priority            += 10;
			}

			$custom_taxonomies = FilterPlus::get();
			if ( is_array( $custom_taxonomies ) && count( $custom_taxonomies ) > 0 ) {
				foreach ( $custom_taxonomies as $slug => $custom_taxonomy ) {
					$filters[ $slug ] = array(
						'label'    => $custom_taxonomy['label'],
						'callback' => array( __CLASS__, 'taxonomies_render' ),
						'custom'   => true, // whether custom filters or not.
						'type'     => 'taxonomy', // Just for data format consistency. because all custom filters are taxonomy itself.
						'priority' => $priority,
					);
					$priority        += 10;
				}
			}
			return $filters;
		}

		/**
		 * Default Settings key for filters.
		 *
		 * @param array $default_settings Default settings keys for filters.
		 */
		public static function default_settings_keys( $default_settings ) {
			$filters          = array();
			$taxonomy_filters = self::taxonomy_filters();
			foreach ( $taxonomy_filters as $taxonomy => $taxonomy_args ) {
				$filter = array(
					'show'  => true,
					'label' => $taxonomy_args['label'],
				);
				if ( isset( $taxonomy_args['custom'] ) && $taxonomy_args['custom'] ) {
					$filters['custom'][ $taxonomy ] = $filter;
				} else {
					$filters['default'][ $taxonomy ] = $filter;
				}
			}

			$default_settings['filters'] = $filters;
			return $default_settings;
		}

		/**
		 * Alternative way to whole get request method to get terms.
		 *
		 * @param string $taxonomy Taxonomoy name.
		 * @return array
		 */
		public static function get_requested_taxonomy_terms( $taxonomy = '' ) {
			if ( ! $taxonomy ) {
				return array();
			}

			$nonce_name   = Nonce::get_nonce_name();
			$nonce_action = Nonce::get_nonce_action();
			/**
			* Nonce Verification.
			*/
			if ( ! isset( $_REQUEST[ $nonce_name ] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_REQUEST[ $nonce_name ] ) ), $nonce_action ) ) {
				return array();
			}
			$terms = isset( $_GET[ $taxonomy ] ) ? array_map( 'sanitize_text_field', wp_unslash( $_GET[ $taxonomy ] ) ) : array();
			return $terms;
		}
	}
}
