<?php
/**
 * Tripzzy TemplateHooks.
 *
 * @package tripzzy
 */

namespace Tripzzy\Core\Helpers;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
use Tripzzy\Core\Traits\SingletonTrait;
use Tripzzy\Core\Helpers\Strings;

if ( ! class_exists( 'Tripzzy\Core\Helpers\TemplateHooks' ) ) {
	/**
	 * Tripzzy TemplateHooks Class.
	 *
	 * @since 1.0.0
	 */
	class TemplateHooks {
		use SingletonTrait;

		/**
		 * Constructor.
		 */
		public function __construct() {
			add_action( 'tripzzy_archive_before_content', array( 'Tripzzy\Core\Helpers\TripFilter', 'render_trip_filters' ) );
			add_action( 'tripzzy_archive_after_listing', array( 'Tripzzy\Core\Helpers\Pagination', 'init' ) );
			add_action( 'tripzzy_archive_after_listing', array( __CLASS__, 'load_more' ) );

			// Single page.
			add_action( 'tripzzy_single_page_content', array( 'Tripzzy\Core\Helpers\TripMap', 'render' ) );
			add_action( 'tripzzy_single_page_content', array( 'Tripzzy\Core\Helpers\TripItineraries', 'render' ) );
			add_action( 'tripzzy_single_page_content', array( 'Tripzzy\Core\Helpers\TripInfos', 'render' ) );
			add_action( 'tripzzy_single_page_content', array( 'Tripzzy\Core\Helpers\TripIncludesExcludes', 'render' ) );
			add_action( 'tripzzy_single_page_content', array( 'Tripzzy\Core\Helpers\TripGallery', 'render' ) );
			add_action( 'tripzzy_single_page_content', array( 'Tripzzy\Core\Helpers\TripDates', 'render' ) );
			add_action( 'tripzzy_single_page_content', array( 'Tripzzy\Core\Helpers\TripFaqs', 'render' ) );
			add_action( 'tripzzy_single_page_content', array( 'Tripzzy\Core\Helpers\Reviews', 'render' ) );
		}

		/**
		 * Wrapper element to add load more button in archive page.
		 *
		 * @return void
		 */
		public static function load_more() {
			$strings   = Strings::get();
			$labels    = $strings['labels'] ?? array();
			$load_more = $labels['load_more'] ?? '';
			?>
			<div id="tripzzy-load-more-trips" class="tripzzy-load-more-trips tripzzy-load-more-link" style="display:none">
				<a href="#" id="tripzzy-load-more" class="tripzzy-load-more" >
					<?php echo esc_html( $load_more ); ?>
				</a>
			</div>
			<?php
		}
	}
}
