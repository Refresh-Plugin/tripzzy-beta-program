<?php
/**
 * Tripzzy Images.
 *
 * @package tripzzy
 */

namespace Tripzzy\Core;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;


if ( ! class_exists( 'Tripzzy\Core\Image' ) ) {
	/**
	 * Tripzzy Images.
	 *
	 * @since 1.0.0
	 */
	class Image {

		/**
		 * Get image by image id.
		 *
		 * @param int   $image_id Image id.
		 * @param array $image_size Default Image size for thumbnail.
		 * @since 1.0.0
		 */
		public static function get( $image_id, $image_size = 'tripzzy_thumbnail' ) {
			if ( ! $image_id ) {
				return;
			}
			$image_data = wp_get_attachment_image_src( $image_id, $image_size );
			if ( ! $image_data ) {
				return;
			}
			$src       = $image_data[0];
			$image_alt = get_post_meta( $image_id, '_wp_attachment_image_alt', true );
			$title     = get_the_title( $image_id );

			?>
			<img alt="<?php echo esc_attr( $image_alt ); ?>" src="<?php echo esc_url( $src ); ?>" title="<?php echo esc_attr( $title ); ?>"/>
			<?php
		}

		/**
		 * Get thumbnail by trip id.
		 *
		 * @param int   $trip_id Image id.
		 * @param array $image_size Default Image size for thumbnail.
		 * @since 1.0.0
		 */
		public static function get_thumbnail( $trip_id, $image_size = 'tripzzy_thumbnail' ) {
			if ( ! $trip_id ) {
				return;
			}

			$image_id = get_post_thumbnail_id( $trip_id );

			if ( ! $image_id ) {
				self::default_thumbnail();
				return;
			}

			$image_data = wp_get_attachment_image_src( $image_id, $image_size );
			if ( ! $image_data ) {
				self::default_thumbnail();
				return;
			}
			$src       = $image_data[0];
			$image_alt = get_post_meta( $image_id, '_wp_attachment_image_alt', true );

			?>
			<img alt="<?php echo esc_attr( $image_alt ); ?>" src="<?php echo esc_url( $src ); ?>" title="<?php the_title(); ?>"/>
			<?php
		}

		/**
		 * Returns thumbnail url by trip id.
		 *
		 * @param int   $trip_id Image id.
		 * @param array $image_size Default Image size for thumbnail.
		 * @return string
		 */
		public static function get_thumbnail_url( $trip_id, $image_size = 'tripzzy_thumbnail' ) {
			$url = get_the_post_thumbnail_url( $trip_id, $image_size );
			return $url ? $url : self::default_thumbnail_url();
		}

		/**
		 * List of image size.
		 *
		 * @since 1.0.0
		 */
		private static function image_sizes() {
			$sizes = array(
				'tripzzy_thumbnail'        => array(
					'width'  => 520,
					'height' => 390,
					'crop'   => true,
					'label'  => __( 'Tripzzy Thumbnail', 'tripzzy' ),
				),
				'tripzzy_slider_thumbnail' => array(
					'width'  => 848,
					'height' => 420,
					'crop'   => true,
					'label'  => __( 'Tripzzy Slider Thumbnail', 'tripzzy' ),
				),
			);
			return apply_filters( 'tripzzy_filter_image_sizes', $sizes );
		}

		/**
		 * Fallback Thumbnail image.
		 */
		public static function default_thumbnail() {

			// need to pass image size as param to use multiple sizes.
			?>
			<img alt="Tripzzy Thumbnail" src="<?php echo esc_url( self::default_thumbnail_url() ); ?>" title="<?php the_title(); ?>"/>
			<?php
		}

		/**
		 * Returns url of fallback thumbnail image.
		 *
		 * @return string
		 * @since 1.0.0
		 */
		public static function default_thumbnail_url() {
			return set_url_scheme( apply_filters( 'tripzzy_filter_default_thumbnail_url', sprintf( '%sassets/images/thumbnail.jpg', esc_url( TRIPZZY_PLUGIN_DIR_URL ) ) ) );
		}

		/**
		 * Add Images Sizes for Tripzzy.
		 *
		 * @since 1.0.0
		 */
		public static function add_image_sizes() {
			$sizes = self::image_sizes();

			if ( is_array( $sizes ) && count( $sizes ) > 0 ) {
				foreach ( $sizes as $name => $data ) {
					add_image_size( $name, $data['width'], $data['height'], $data['crop'] );
				}
			}
		}

		/**
		 * List image size in image block.
		 *
		 * @param array $image_sizes List of available image sizes including default image size.
		 * @since 1.0.0
		 */
		public static function list_image_sizes( $image_sizes ) {
			$sizes = self::image_sizes();
			if ( is_array( $sizes ) && count( $sizes ) > 0 ) {
				foreach ( $sizes as $name => $data ) {
					$image_sizes[ $name ] = $data['label'];
				}
			}
			return $image_sizes;
		}
	}
}
