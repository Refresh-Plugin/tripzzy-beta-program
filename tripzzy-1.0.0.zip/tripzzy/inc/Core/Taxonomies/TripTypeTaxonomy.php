<?php
/**
 * Tripzzy Taxonomy.
 *
 * @package tripzzy
 */

namespace Tripzzy\Core\Taxonomies;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use Tripzzy\Core\Bases\TaxonomyBase;
use Tripzzy\Core\Helpers\MetaHelpers;
use Tripzzy\Core\Helpers\Strings;
use Tripzzy\Admin\Permalinks;

if ( ! class_exists( 'Tripzzy\Core\Taxonomies\TripTypeTaxonomy' ) ) {
	/**
	 * Tripzzy Taxonomy Class.
	 *
	 * @since 1.0.0
	 */
	class TripTypeTaxonomy extends TaxonomyBase {
		/**
		 * Taxonomy Key to register Taxonomy.
		 *
		 * @since 1.0.0
		 * @var string
		 */
		protected static $taxonomy = 'tripzzy_trip_type';

		/**
		 * Object Types.
		 *
		 * @since 1.0.0
		 * @var string
		 */
		protected static $object_types = array( 'tripzzy' );

		/**
		 * Permalinks.
		 *
		 * @since 1.0.0
		 * @var array
		 */
		protected static $slugs;

		/**
		 * Constructor.
		 */
		public function __construct() {
			$taxonomy    = self::$taxonomy;
			self::$slugs = Permalinks::get();
			add_filter( 'tripzzy_filter_taxonomy_args', array( $this, 'init_args' ) );
			// Term meta.
			add_filter( 'tripzzy_filter_term_meta_fields', array( $this, 'init_term_meta_fields' ) );

			// Manage Taxonomy columns.
			add_filter( "manage_edit-{$taxonomy}_columns", array( $this, 'taxonomy_columns' ) );
			add_filter( "manage_{$taxonomy}_custom_column", array( $this, 'taxonomy_column_content' ), 10, 3 );
		}

		/**
		 * Taxonomy arguments.
		 *
		 * @since 1.0.0
		 */
		protected static function taxonomy_args() {
			$labels = array(
				'name'              => _x( 'Trip Types', 'taxonomy general name', 'tripzzy' ),
				'singular_name'     => _x( 'Trip Type', 'taxonomy singular name', 'tripzzy' ),
				'search_items'      => __( 'Search Trip Types', 'tripzzy' ),
				'all_items'         => __( 'All Trip Types', 'tripzzy' ),
				'parent_item'       => __( 'Parent Trip Type', 'tripzzy' ),
				'parent_item_colon' => __( 'Parent Trip Type:', 'tripzzy' ),
				'edit_item'         => __( 'Edit Trip Type', 'tripzzy' ),
				'update_item'       => __( 'Update Trip Type', 'tripzzy' ),
				'add_new_item'      => __( 'Add New Trip Type', 'tripzzy' ),
				'new_item_name'     => __( 'New Trip Type', 'tripzzy' ),
				'menu_name'         => __( 'Trip Types', 'tripzzy' ),
			);

			$args = array(
				'hierarchical'      => true,
				'public'            => true,
				'labels'            => $labels,
				'show_ui'           => true,
				'show_admin_column' => true,
				'show_in_rest'      => true,
				'query_var'         => true,
				'rewrite'           => array( 'slug' => self::$slugs['tripzzy_trip_type_base'] ),
				'object_types'      => self::$object_types, // Where to add This taxonomy.
				'icon'              => 'fa-solid fa-suitcase-rolling', // only for trip info section default icon.
				'priority'          => 30,
			);
			return $args;
		}

		/**
		 * Term meta form fields.
		 *
		 * @since 1.0.0
		 */
		protected static function term_meta_fields() {
			$fields = array(
				'taxonomy_image' =>
				array(
					'type'                => 'image',
					'label'               => __( 'Taxonomy image', 'tripzzy' ),
					'name'                => 'taxonomy_image',
					'id'                  => 'taxonomy-image',
					'class'               => 'taxonomy-image',
					'placeholder'         => '',
					'required'            => false,
					'priority'            => 10,
					'value'               => '',
					'input_wrapper'       => 'span',
					'input_wrapper_class' => 'term-meta-input',
					'input_description'   => __( 'Taxonomy default thumbnail image', 'tripzzy' ),
					// Additional configurations.
					'is_new'              => true, // Whether it is new field just recently added or not? Always Need to set false for default fields.
					'is_default'          => true, // Whether it is Default field or not.
					'enabled'             => true, // soft enable. this field can be disabled.
					'force_enabled'       => true, // You can not disable if this set to true.
				),
			);
			return $fields;
		}

		/**
		 * Taxonomy column Titles
		 *
		 * @param array $columns List of column names.
		 * @return array
		 */
		public function taxonomy_columns( $columns ) {
			$columns['thumbnail'] = __( 'Thumbnail', 'tripzzy' );
			return $columns;
		}

		/**
		 * Taxonomy column Titles
		 *
		 * @param array $content Column content.
		 * @param array $column_name Column title.
		 * @param array $term_id current term id.
		 * @return array
		 */
		public function taxonomy_column_content( $content, $column_name, $term_id ) {
			$labels = Strings::get()['labels'];
			if ( 'thumbnail' === $column_name ) {
				$img_id = MetaHelpers::get_term_meta( $term_id, 'taxonomy_image' );
				if ( $img_id ) {
					$content = wp_get_attachment_image( $img_id, array( 120, 160 ) );
				} else {
					$content = $labels['na'] ?? '';
				}
			}
			return $content;
		}
	}
}
