<?php
/**
 * Singleton trait for plugin.
 *
 * @package tripzzy
 * @since 1.0.0
 */

namespace Tripzzy\Core\Traits;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Define Trait.
 */
trait AdminMenuTrait {
	/**
	 * All Submenus for Tripzzy.
	 *
	 * @since 1.0.0
	 * @return String
	 */
	public static function get_submenus() {
		$menus = array(
			'edit.php?post_type=tripzzy_booking' => array(
				array(
					'priority'   => '130',
					'page_title' => __( 'Filters +', 'tripzzy' ),
					'menu_title' => __( 'Filters +', 'tripzzy' ),
					'menu_slug'  => 'tripzzy-custom-categories',
					'callback'   => array( 'Tripzzy\Admin\Views\FilterPlusView', 'render' ),
				),
				array(
					'priority'   => '150',
					'page_title' => __( 'Settings:Tripzzy', 'tripzzy' ),
					'menu_title' => __( 'Settings', 'tripzzy' ),
					'menu_slug'  => 'tripzzy-settings',
					'callback'   => array( 'Tripzzy\Admin\Views\SettingsView', 'render' ),
				),

				array(
					'priority'   => '200',
					'page_title' => __( 'System Information', 'tripzzy' ),
					'menu_title' => __( 'System Information', 'tripzzy' ),
					'menu_slug'  => 'tripzzy-system-info',
					'callback'   => array( 'Tripzzy\Admin\Views\SystemInfoView', 'render' ),
				),
			),
		);
		/**
		 * Sub Menu filter hook to modify custom submenus.
		 *
		 * @since 1.0.0
		 */
		return apply_filters( 'tripzzy_filter_submenus', $menus );
	}
}
