<?php
/**
 * Plugin Name: Tripzzy
 * Plugin URI: http://refreshthemes.com/tripzzy
 * Description: Tripzzy is designed to help you create and manage your travel-related content.
 * Version: 1.0.0
 * Author: Refresh Themes
 * Author URI: http://refreshthemes.com
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Tested up to: 6.3
 *
 * Text Domain: tripzzy
 * Domain Path: /languages/
 *
 * @package tripzzy
 * @author  Refresh Themes
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

define( 'TRIPZZY_VERSION', '1.0.0' );
define( 'TRIPZZY_PLUGIN_FILE', __FILE__ );

if ( ! class_exists( 'Tripzzy' ) ) {
	require_once 'inc/class-tripzzy.php';
}

/**
 * Tripzzy Main Class.
 *
 * @return object
 */
function tripzzy() {
	return Tripzzy::instance();
}
tripzzy();
