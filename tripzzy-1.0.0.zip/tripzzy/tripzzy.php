<?php
/**
 * Plugin Name: Tripzzy
 * Plugin URI: http://refreshthemes.com/tripzzy
 * Update URI: https://raw.githubusercontent.com/Refresh-Plugin/tripzzy-beta-program/main/info.json
 * Description: Tripzzy is designed to help you create and manage your travel-related content.
 * Version: 1.0.0
 * Author: Refresh Themes
 * Author URI: http://refreshthemes.com
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Tested up to: 6.3
 *
 * Text Domain: tripzzy
 * Domain Path: /languages/
 *
 * @package tripzzy
 * @author  Refresh Themes
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

define( 'TRIPZZY_VERSION', '1.0.0' );
define( 'TRIPZZY_PLUGIN_FILE', __FILE__ );

if ( file_exists( dirname( TRIPZZY_PLUGIN_FILE ) . '/tripzzy-beta.php' ) ) {
	require_once dirname( TRIPZZY_PLUGIN_FILE ) . '/tripzzy-beta.php';
}

if ( ! class_exists( 'Tripzzy' ) ) {
	require_once 'inc/class-tripzzy.php';
}

/**
 * Tripzzy Main Class.
 *
 * @return object
 */
function tripzzy() {
	return Tripzzy::instance();
}
tripzzy();
