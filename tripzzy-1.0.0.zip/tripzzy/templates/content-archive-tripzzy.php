<?php
/**
 * The template for displaying all content of archive trip.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package tripzzy
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
use Tripzzy\Core\Template;
Template::get_template( 'layouts/default/layout-archive-tripzzy' );
