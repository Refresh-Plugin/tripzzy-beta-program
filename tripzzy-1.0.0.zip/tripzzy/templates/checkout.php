<?php
/**
 * Checkout trip page
 *
 * @package tripzzy
 * @since   1.0.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
use Tripzzy\Core\Template;
use Tripzzy\Core\Helpers\TripFilter;
use Tripzzy\Core\Helpers\Amount;
use Tripzzy\Core\Helpers\Coupon;
use Tripzzy\Core\Helpers\Trip;
use Tripzzy\Core\Helpers\Strings;
use Tripzzy\Core\Image;

$cart          = tripzzy()->cart;
$cart_contents = $cart->get_cart_contents();
$cart_totals   = $cart->get_totals();
$coupon_code   = Coupon::get_applied_coupon_code();
$input_attr    = ! empty( $coupon_code ) ? 'disabled' : '';
$queries       = Strings::get()['queries'];
get_header(); ?>
<?php do_action( 'tripzzy_before_main_content' ); ?>
<div class="tripzzy-container"><!-- Main Wrapper element for Tripzzy -->
	<div class="tz-row">
		<?php do_action( 'tripzzy_before_checkout_form' ); ?>
		<div class="tz-col tz-cols-7-lg tz-cols-8-xl">
			<div class="tripzzy-checkout-form">
				<?php if ( count( $cart_contents ) > 0 ) : ?>
					<div class="tripzzy-promo-coupon-wrapper" id="tripzzy-promo-coupon-wrapper">
						<form>
							<div id="tripzzy-coupon-block" style="display:block;">
								<h5 class="tripzzy-apply-coupon-title">
									<p><?php echo esc_html( __( 'Have a Coupon code?', 'tripzzy' ) ); ?></p>
								</h5>
								<p><?php echo esc_html( __( 'Add your coupon code below to get your discount.', 'tripzzy' ) ); ?></p>
								<div class="tripzzy-coupon-inputs" id="tripzzy-coupon-inputs">
									<input type="text" class="input-text" id="tripzzy-coupon-code" value="<?php echo esc_attr( $coupon_code ); ?>" <?php echo esc_attr( $input_attr ); ?> placeholder="<?php echo esc_attr( __( 'Coupon Code', 'tripzzy' ) ); ?>">
									<?php if ( ! empty( $coupon_code ) ) : ?>
										<button class="tripzzy-clear-coupon-btn" id="tripzzy-clear-coupon-btn"><?php echo esc_html( __( 'Clear', 'tripzzy' ) ); ?></button>
									<?php else : ?>
										<input type="submit" class="tripzzy-apply-coupon-btn tz-btn tz-btn-solid tz-btn-sm" id="tripzzy-apply-coupon-btn" name="apply_coupon" value="<?php echo esc_attr( __( 'Apply', 'tripzzy' ) ); ?>">
									<?php endif; ?>
								</div>
							</div>
							<div id="tripzzy-coupon-response-msg">
							</div>
						</form>
					</div>
				<?php endif; ?>
				<?php
				while ( have_posts() ) :
					the_post();
					the_content();
				endwhile; // end of the loop.
				?>
			</div>
		</div>
		<?php if ( count( $cart_contents ) > 0 ) : ?>
			<div class="tz-col tz-cols-5-lg tz-cols-4-xl">
				<div class="tripzzy-order-info">
					<h3><?php echo esc_attr( __( 'Order Summary', 'tripzzy' ) ); ?></h3>
					<div class="tripzzy-orders">
						<ol>
							<?php
							foreach ( $cart_contents as $cart_key => $item ) :
								$package_id = isset( $item['package_id'] ) ? $item['package_id'] : '';
								if ( ! $item['trip_id'] ) {
									continue;
								}

								$trip     = new Trip( $item['trip_id'] );
								$packages = $trip->packages();
								$package  = $packages->get_package( $package_id );
								?>
								<li class="tripzzy-cart-item">
									<div class="tripzzy-cart-trip-thumbnail">
										<?php Image::get_thumbnail( $item['trip_id'] ); ?>
									</div>
									<div class="tripzzy-cart-trip-details">
										<span class="tripzzy-cart-trip-name"><?php echo esc_html( $item['title'] ); ?></span>
										<span class="tripzzy-cart-trip-date"><?php echo esc_attr( __( 'Date', 'tripzzy' ) ); ?>: <strong><?php echo esc_html( $item['start_date'] ); ?></strong></span>
										<span class="tripzzy-cart-trip-package"><?php echo esc_attr( __( 'Package', 'tripzzy' ) ); ?>: <strong><?php echo esc_html( $package->get_title() ); ?></strong></span>
									</div>
									<div class="tripzzy-cart-price-wrap">
										<?php echo esc_html( Amount::display( $item['item_total'] ) ); ?>
									</div>
									<button class="tripzzy-remove-cart-item" data-cart-item-id="<?php echo esc_attr( $cart_key ); ?>" ><?php echo esc_attr( __( 'Remove', 'tripzzy' ) ); ?></button>
								</li>
							<?php endforeach; ?>
						</ol>
						<div class="tripzzy-cart-footer">
							<?php if ( $cart_totals['discount_total'] > 0 ) : ?>
								<div class="tripzzy-cart-subtotal-wrap">
									<div class="tripzzy-cart-gross-total">
										<span class="tripzzy-cart-price-label"><?php echo esc_attr( __( 'Subtotal', 'tripzzy' ) ); ?></span>
										<span class="tripzzy-cart-total-price gross-total"><?php echo esc_html( Amount::display( $cart_totals['gross_total'] ) ); ?></span>
									</div>
									<div class="tripzzy-cart-gross-total">
										<span class="tripzzy-cart-price-label"><?php echo esc_attr( __( 'Discount', 'tripzzy' ) ); ?></span>
										<span class="tripzzy-cart-total-price discount-total">(<?php echo esc_html( Amount::display( $cart_totals['discount_total'] ) ); ?>)</span>
									</div>
								</div>
							<?php endif; ?>
							<div class="tripzzy-cart-nettotal-wrap">
								<div class="tripzzy-cart-net-total">
									<span class="tripzzy-cart-price-label"><?php echo esc_attr( __( 'Total', 'tripzzy' ) ); ?></span>
									<span class="tripzzy-cart-total-price net-total"><?php echo esc_html( Amount::display( $cart_totals['net_total'] ) ); ?></span>
								</div>
							</div>
							<!-- <a href="#" class="tz-btn tz-btn-solid tz-btn-full">Confirm order</a> -->
							<div id="tripzzy-cart-response-message"></div>
						</div>
					</div>
				</div>
			</div>
		<?php endif; ?>
	</div>
</div>
<?php do_action( 'tripzzy_after_main_content' ); ?>
<?php
get_footer();
