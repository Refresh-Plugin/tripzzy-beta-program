<?php
/**
 * Tripzzy TemplateHooks.
 *
 * @package tripzzy
 */

namespace Tripzzy\Core\Helpers;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
use Tripzzy\Core\Traits\SingletonTrait;
use Tripzzy\Core\Helpers\Strings;
use Tripzzy\Core\Helpers\Page;

if ( ! class_exists( 'Tripzzy\Core\Helpers\TemplateHooks' ) ) {
	/**
	 * Tripzzy TemplateHooks Class.
	 *
	 * @since 1.0.0
	 */
	class TemplateHooks {
		use SingletonTrait;

		/**
		 * Constructor.
		 */
		public function __construct() {
			add_action( 'tripzzy_archive_before_content', array( 'Tripzzy\Core\Helpers\TripFilter', 'render_trip_filters' ) );
			add_action( 'tripzzy_archive_after_listing', array( 'Tripzzy\Core\Helpers\Pagination', 'init' ) );
			add_action( 'tripzzy_archive_after_listing', array( __CLASS__, 'load_more' ) );

			// Single page.
			add_action( 'tripzzy_single_page_content', array( __CLASS__, 'render_trip_details' ) );

			// Sticky tab. @since 1.0.2.
			add_action( 'tripzzy_before_main_content', array( 'Tripzzy\Core\Helpers\TripStickyTab', 'render' ) );
		}

		/**
		 * Render All single trip page sections.
		 *
		 * @since 1.0.2
		 *
		 * @return void
		 */
		public static function render_trip_details() {
			$trip_tabs    = TripStickyTab::get( get_the_ID() );
			$default_tabs = TripStickyTab::get_default_sticky_tab_items();
			foreach ( $trip_tabs as $trip_tab ) {
				$enabled = ! ! $trip_tab['enabled'] ?? false;
				if ( ! $enabled ) {
					continue;
				}
				$render_class = $trip_tab['render_class'] ?? '';
				if ( ! $render_class ) {
					// check in default.
					$key = array_search( $trip_tab['link'] ?? '', array_column( $default_tabs, 'link' ) ); // @phpcs:ignore
					if ( false !== $key ) {
						$render_class = $default_tabs[ $key ]['render_class'] ?? '';
					}
				}
				if ( $render_class ) { // need to check method exists.
					call_user_func( array( $render_class, 'render' ) );
				}
			}
		}

		/**
		 * Wrapper element to add load more button in archive page.
		 *
		 * @return void
		 */
		public static function load_more() {
			$strings   = Strings::get();
			$labels    = $strings['labels'] ?? array();
			$load_more = $labels['load_more'] ?? '';
			?>
			<div id="tripzzy-load-more-trips" class="tripzzy-load-more-trips tripzzy-load-more-link" style="display:none"><a href="#" id="tripzzy-load-more" class="tripzzy-load-more" ><?php echo esc_html( $load_more ); ?></a></div><!-- Added in one line to resolve wpautop issue in block template -->
			<?php
		}
	}
}
