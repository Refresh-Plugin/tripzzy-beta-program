<?php
/**
 * Conditional functions for Tripzzy.
 *
 * @package tripzzy
 */

/**
 * Exit if accessed directly.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'tripzzy_site_is_https' ) ) {
	/**
	 * Check whether website uses https or not.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	function tripzzy_site_is_https() {
		return false !== strstr( get_option( 'home' ), 'https:' );
	}
}

if ( ! function_exists( 'tripzzy_post_exists' ) ) {
	/**
	 * Check whether post is exists or not.
	 *
	 * @param int $post_id Post id.
	 * @since 1.0.0
	 * @return bool
	 */
	function tripzzy_post_exists( $post_id ) {
		return is_string( get_post_status( $post_id ) );
	}
}

if ( ! function_exists( 'tripzzy_is_url' ) ) {
	/**
	 * Check for valid url.
	 *
	 * @param string $value Value to check.
	 * @since 1.0.0
	 * @return boolean
	 */
	function tripzzy_is_url( $value ) {
		return filter_var( $value, FILTER_VALIDATE_URL ) !== false;
	}
}

if ( ! function_exists( 'tripzzy_is_email' ) ) {
	/**
	 * Check for valid email.
	 *
	 * @param string $value Value to check.
	 * @since 1.0.0
	 * @return boolean
	 */
	function tripzzy_is_email( $value ) {
		return filter_var( $value, FILTER_VALIDATE_EMAIL ) !== false;
	}
}

if ( ! function_exists( 'tripzzy_is_fse_theme' ) ) {
	/**
	 * Check current active theme is block/fse theme or not.
	 *
	 * @since 1.0.6
	 * @return boolean
	 */
	function tripzzy_is_fse_theme() {
		if ( function_exists( 'wp_is_block_theme' ) ) {
			return (bool) wp_is_block_theme();
		}
		if ( function_exists( 'gutenberg_is_fse_theme' ) ) {
			return (bool) gutenberg_is_fse_theme();
		}

		return false;
	}
}
