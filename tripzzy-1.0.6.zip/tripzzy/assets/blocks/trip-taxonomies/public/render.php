<?php
/**
 * Tripzzy Trips.
 *
 * @since 1.0.1
 * @since 1.0.5 API updated to v3 and settings and styles added.
 * @package tripzzy
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use Tripzzy\Core\Image;
use Tripzzy\Core\Helpers\MetaHelpers;
use Tripzzy\Core\Assets;
use Tripzzy\Core\Blocks;

$data          = $attributes['query'] ?? array();
$tripzzy_terms = get_terms(
	array(
		'taxonomy'   => $data['taxonomy'] ?? 'tripzzy_trip_destination',
		'orderby'    => $data['orderBy'] ?? 'name',
		'order'      => $data['order'] ?? 'asc',
		'number'     => $data['numberOfItems'] ?? 4,
		'hide_empty' => false,
	)
);
// Styles.
$gap            = $attributes['gap'] ?? '0';
$has_overlay    = ! ! $attributes['showOverlay'] && isset( $attributes['overlayColor'] );
$show_count     = ! ! $attributes['showCount'];
$title_position = $attributes['titlePosition'] ?? 'bottom';
$text_color     = Blocks::get_text_color( $attributes );

switch ( $title_position ) {
	case 'top':
		$title_position_style = array(
			'top'    => 0,
			'bottom' => 'inherit',
		);
		break;
	case 'middle':
		$title_position_style = array(
			'transform' => 'translateY(-50%)',
			'top'       => '50%',
			'bottom'    => 'inherit',
		);
		break;
	default:
		$title_position_style = array();
		break;
}
$styles = array(
	array(
		'selector' => '.tripzzy-trip-categories .tripzzy-trip-category-listings',
		'css'      => array(
			'grid-gap'              => $gap,
			'grid-template-columns' => 'repeat(auto-fill, minmax( ' . ( $attributes['itemWidth'] ?? '320px' ) . ', 1fr))',
		),
	),
	array(
		'selector' => '.tripzzy-trip-categories .tripzzy-trip-category-listings .tripzzy-trip-category .tripzzy-trip-category-img img',
		'css'      => array( 'height' => $attributes['itemHeight'] ?? '300px' ),
	),
	array(
		'selector' => '.tripzzy-trip-categories .tripzzy-trip-category-listings .tripzzy-trip-category .tripzzy-trip-category-img::after',
		'css'      => array( 'background' => $has_overlay ? $attributes['overlayColor'] : 'transparent' ),
	),
	array(
		'selector' => '.tripzzy-trip-categories .tripzzy-trip-category-title a',
		'css'      => array( 'color' => $text_color ),
	),
);
if ( count( $title_position_style ) > 0 ) {
	$styles[] = array(
		'selector' => '.tripzzy-trip-category-listings .tripzzy-trip-category-title',
		'css'      => $title_position_style,
	);
}
?>
<style>
<?php echo wp_kses_post( Assets::array_to_css( $styles ) ); ?>
</style>
<div class="tripzzy-trip-categories" >
	<div class="tz-row tripzzy-trip-category-listings">
		<?php if ( is_array( $tripzzy_terms ) && count( $tripzzy_terms ) > 0 ) : ?>
			<?php
			foreach ( $tripzzy_terms as $tripzzy_term ) :
				/* translators: %d Term count */
				$term_count    = sprintf( _n( '%d trip', '%d trips', $tripzzy_term->count, 'tripzzy' ), $tripzzy_term->count );
				$thumbnail_url = MetaHelpers::get_term_meta( $tripzzy_term->term_id, 'taxonomy_image_url' );
				if ( ! $thumbnail_url ) {
					$thumbnail_url = Image::default_thumbnail_url();
				}
				?>
				<div class="tz-col">
					<div class="tripzzy-trip-category">
						<div class="tripzzy-trip-category-img">
							<img src="<?php echo esc_url( $thumbnail_url ); ?>" />
							<h3 class="tripzzy-trip-category-title tripzzy-trip-category-bottom-content">
								<a href="<?php echo esc_url( get_term_link( $tripzzy_term->term_id ) ); ?>">
									<?php echo esc_html( $tripzzy_term->name ); ?>
									<?php if ( $show_count ) : ?>
										<span class="tripzzy-trip-category-count" >
											<?php echo esc_html( $term_count ); ?>
										</span>
									<?php endif; ?>
								</a>
							</h3>
						</div>
					</div>
				</div>
			<?php endforeach; ?>	
		<?php endif; ?>
	</div>
</div>
