<?php
/**
 * Checkout trip page
 *
 * @package tripzzy
 * @since   1.0.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
use Tripzzy\Core\Http\Nonce;
use Tripzzy\Core\Helpers\ErrorMessage;

get_header(); ?>
<?php do_action( 'tripzzy_before_main_content' ); ?>
<div class="tripzzy-container"><!-- Main Wrapper element for Tripzzy -->
	<div class="tripzzy-content">
		<div class="tripzzy-thank-you">
			<?php

			if ( ! Nonce::verify() ) {
				$error_message = ErrorMessage::get( 'page_expired' );
				$tm_errors     = $error_message->errors;
				?>
				<span class="tripzzy-error">
					<?php
					foreach ( $tm_errors as $tm_error ) {
						echo esc_html( $tm_error[0] );
					}
					?>
				</span>
				<?php
			} else {
				while ( have_posts() ) :
					the_post();
					the_content();
				endwhile; // end of the loop.
			}
			?>
		</div>
	</div>
</div>
<?php do_action( 'tripzzy_after_main_content' ); ?>
<?php
get_footer();
