<?php
/**
 * Tripzzy Shortcode
 *
 * @package tripzzy
 */

namespace Tripzzy\Core\Shortcodes;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use Tripzzy\Core\Bases\ShortcodeBase;
use Tripzzy\Core\Forms\Form;
use Tripzzy\Core\Forms\CheckoutForm;
use Tripzzy\Core\Helpers\Notice;
use Tripzzy\Core\Helpers\Page;
use Tripzzy\Core\Helpers\Currencies;
use Tripzzy\Core\Payment\PaymentGateways;
use Tripzzy\Core\Cart;

if ( ! class_exists( 'Tripzzy\Core\Shortcodes\CheckoutPageShortcode' ) ) {
	/**
	 * Trip Info Shortcode Class.
	 *
	 * @since 1.0.0
	 */
	class CheckoutPageShortcode extends ShortcodeBase {
		/**
		 * Shortcode Name
		 *
		 * @since 1.0.0
		 * @var string
		 */
		protected static $shortcode = 'TRIPZZY_CHECKOUT'; // #1.

		/**
		 * Constructor.
		 */
		public function __construct() {
			add_filter( 'tripzzy_filter_shortcode_args', array( $this, 'init_args' ) );
		}

		/**
		 * Add shortcode arguments to register Shortcode from base class.
		 *
		 * @since 1.0.0
		 */
		protected static function shortcode_args() {
			$args = array(
				'shortcode' => self::$shortcode,
				'callback'  => array( 'Tripzzy\Core\Shortcodes\CheckoutPageShortcode', 'render' ), // #2.
			);
			return $args;
		}

		/**
		 * Default Shortcode attributes list.
		 *
		 * @since 1.0.0
		 */
		protected static function default_atts() {
			$atts = array();
			return $atts;
		}

		/**
		 * Render Shortcode content.
		 *
		 * @param array  $atts Shortcode attributes.
		 * @param string $content Additional content for the shortcode.
		 * @since 1.0.0
		 */
		public static function render( $atts, $content = '' ) {
			$cart  = tripzzy()->cart;
			$items = $cart->get_cart_contents();

			if ( empty( $items ) ) {
				/* translators: %s is the trips url. */
				$notice = sprintf( __( 'Please add <a href="%s">trips</a> in the cart first!', 'tripzzy' ), esc_url( Page::get_url( 'trips' ) ) );
				Notice::render( $notice );
				return;
			}
			$atts = self::shortcode_atts( $atts );

			$cart_totals = $cart->get_totals();

			ob_start();
			if ( PaymentGateways::is_test_mode() ) {
				?>
				<div class="tripzzy-test-mode-notice">
					<div class="arrow-right"><span title="<?php esc_html_e( 'You are currently in sandbox mode. This box only visible in sandbox mode.', 'tripzzy' ); ?>">Test Mode</span></div>
				</div>
				<?php
			}
			?>
			<form method="post" name="tripzzy_checkout" id="tripzzy-checkout-form" action="<?php echo esc_url( Page::get_url( 'checkout' ) ); ?>" >
				<?php CheckoutForm::render(); ?>
				<div class="tripzzy-form-field-wrapper">
					<label class="tripzzy-form-label tripzzy-form-label-wrapper">Payment Mode</label>					
					<input type="hidden" name="tripzzy_action" value="tripzzy_book_now" />
					<input type="hidden" name="payment_details" value="" id="tripzzy-payment-details" /> <!-- Add value from payment gateway -->
					<input type="hidden" name="currency" value="<?php echo esc_attr( Currencies::get_code() ); ?>" />
					<input type="hidden" name="payment_amount" value="<?php echo esc_attr( $cart_totals['net_total'] ?? 0 ); ?>" />
					<?php if ( PaymentGateways::has_enabled_gateway() ) : ?>
						<div class="tripzzy-payment-options">
						<?php
						foreach ( PaymentGateways::get_enabled_gateways() as $gateway ) :
							$id      = sprintf( 'tripzzy-payment-mode-%s', $gateway['name'] );
							$checked = PaymentGateways::is_default_gateway( $gateway['name'] ) ? 'checked="checked"' : '';
							?>
							<div class="tripzzy-payment-mode tripzzy-payment-option" > <!-- @todo Need to remove tripzzy-payment-option class -->
								<input type="radio" data-tripzzy-payment-script="<?php echo esc_attr( trim( wp_json_encode( $gateway['scripts'] ) ) ); ?>" id="<?php echo esc_attr( $id ); ?>" <?php echo esc_attr( $checked ); ?> name="payment_mode" value="<?php echo esc_attr( $gateway['name'] ); ?>" /><label for="<?php echo esc_attr( $id ); ?>" ><?php echo esc_html( $gateway['title'] ); ?></label>
							</div>
						<?php endforeach; ?>
						</div>
						<div id="tripzzy-payment-button" class="tripzzy-payment-button tripzzy-is-processing" data-total="<?php echo esc_attr( $cart_totals['net_total'] ?? 0 ); ?>" data-currency="<?php echo esc_attr( Currencies::get_code() ); ?>" ></div>
					<?php else : ?>
						<input type="hidden" name="payment_mode" value="book_now_pay_later" />
						<input class="tz-btn tz-btn-solid" type="submit" name="tripzzy_book_now" value="Book Now" />
					<?php endif; ?>
					<script type="text/html" id="tmpl-tripzzy-book-now-pay-latter">
						<input class="tz-btn tz-btn-solid" type="submit" name="tripzzy_book_now" value="Book Now" />
					</script>

					<div id="tripzzy-checkout-form-response-msg">
						<span class="title" id="tripzzy-checkout-form-response-title" ></span>
						<span class="message" id="tripzzy-checkout-form-response" ></span>
					</div>
				</div>
			</form>
			<?php
			$content = ob_get_contents();
			ob_end_clean();
			return $content;
		}
	}
}
