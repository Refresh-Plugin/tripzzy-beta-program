<?php
/**
 * Tripzzy Blocks Entry.
 *
 * @package tripzzy
 */

namespace Tripzzy\Core;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

// Traits.
use Tripzzy\Core\Traits\SingletonTrait;
if ( ! class_exists( 'Blocks' ) ) {

	/**
	 * Main Class.
	 *
	 * @since 1.0.0
	 */
	final class Blocks {

		use SingletonTrait;

		/**
		 * Constructor.
		 */
		public function __construct() {
			foreach ( glob( sprintf( '%1$sinc/Core/Blocks/*.php', TRIPZZY_ABSPATH ) ) as $filename ) {
				$namespace  = 'Tripzzy\Core\Blocks';
				$class_name = basename( $filename, '.php' );
				if ( class_exists( $namespace . '\\' . $class_name ) ) {
					$name = $namespace . '\\' . $class_name;
					new $name();
				}
			}
		}
	}
}
