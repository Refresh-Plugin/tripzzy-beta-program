<?php
/**
 * Trip ajax class.
 *
 * @package tripzzy
 */

namespace Tripzzy\Core\Ajax;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
use Tripzzy\Core\Traits\SingletonTrait;
use Tripzzy\Core\Helpers\Strings;
use Tripzzy\Core\Helpers\Wishlists;
use Tripzzy\Core\Http\Nonce;
use Tripzzy\Core\Http\Request;

if ( ! class_exists( 'Tripzzy\Core\Ajax\WishlistsAjax' ) ) {
	/**
	 * Wishlist Ajax Class.
	 *
	 * @since 1.0.0
	 */
	class WishlistsAjax {
		use SingletonTrait;

		/**
		 * All available strings.
		 *
		 * @var array
		 */
		private $strings;

		/**
		 * Constructor.
		 */
		public function __construct() {
			$this->strings = Strings::messages();
			// Frontend side Ajax.
			add_action( 'wp_ajax_tripzzy_set_wishlists', array( $this, 'set' ) );
			add_action( 'wp_ajax_nopriv_tripzzy_set_wishlists', array( $this, 'set' ) );
		}

		/**
		 * Ajax callback to get trip data.
		 *
		 * @since 1.0.0
		 */
		public function get() {
			if ( ! Nonce::verify() ) {
				$message = array(
					'message' => $this->strings['nonce_verification_failed'],
				);
				wp_send_json_error( $message );
			}
		}

		/**
		 * Ajax callback to set form data.
		 *
		 * @since 1.0.0
		 */
		public function set() {
			if ( ! Nonce::verify() ) {
				$message = array( 'message' => $this->strings['nonce_verification_failed'] );
				wp_send_json_error( $message );
			}
			$user_id = get_current_user_id();
			// Nonce already verified using Nonce::verify method.
			$data          = array(
				'trip_id' => isset( $_POST['trip_id'] ) ? absint( $_POST['trip_id'] ) : 0, // @codingStandardsIgnoreLine
				'value'   => isset( $_POST['value'] ) && 'true' === $_POST['value'] ? true : false, // @codingStandardsIgnoreLine
			);
			$response_data = Wishlists::update( $user_id, $data );

			if ( $user_id && $response_data ) {
				wp_send_json_success( $response_data, 200 );
			}
		}
	}

	WishlistsAjax::instance();
}
