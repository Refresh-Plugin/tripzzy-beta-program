<?php
/**
 * Enquiry Post type.
 *
 * @package tripzzy
 */

namespace Tripzzy\Core\PostTypes;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use Tripzzy\Core\Bases\PostTypeBase;
use Tripzzy\Core\Forms\EnquiryForm;
use Tripzzy\Core\Helpers\MetaHelpers;
use Tripzzy\Core\Helpers\Page;
use Tripzzy\Core\Http\Nonce;
use Tripzzy\Core\Http\Request;


if ( ! class_exists( 'Tripzzy\Core\PostTypes\EnquiryPostType' ) ) {
	/**
	 * Enquiry Post Type Class.
	 *
	 * @since 1.0.0
	 */
	class EnquiryPostType extends PostTypeBase {
		/**
		 * Post Type Key to register post type.
		 *
		 * @since 1.0.0
		 * @var string
		 */
		protected static $post_type = 'tripzzy_enquiry';

		/**
		 * Constructor.
		 */
		public function __construct() {
			add_filter( 'tripzzy_filter_post_type_args', array( $this, 'init_args' ) );
			add_filter( 'tripzzy_filter_meta_box_args', array( $this, 'init_meta_box_args' ), 10, 2 );
			add_action( 'tripzzy_' . self::$post_type . '_save_post', array( __CLASS__, 'save_meta' ) );

			add_filter( 'display_post_states', array( $this, 'display_post_states' ), 10, 2 );
			add_filter( 'load-post.php', array( $this, 'mark_as_read' ) );
		}

		/**
		 * Post Type arguments.
		 *
		 * @since 1.0.0
		 */
		protected static function post_type_args() {
			$labels = array(
				'add_new'            => _x( 'New Enquiry', 'tripzzy', 'tripzzy' ),
				'add_new_item'       => __( 'Add New Enquiry', 'tripzzy' ),
				'all_items'          => __( 'Enquiries', 'tripzzy' ),
				'edit_item'          => __( 'Edit Enquiry', 'tripzzy' ),
				'menu_name'          => _x( 'Enquiries', 'admin menu', 'tripzzy' ),
				'name'               => _x( 'Enquiries', 'post type general name', 'tripzzy' ),
				'name_admin_bar'     => _x( 'Enquiry', 'add new on admin bar', 'tripzzy' ),
				'new_item'           => __( 'New Enquiry', 'tripzzy' ),
				'not_found'          => __( 'No Enquiries found.', 'tripzzy' ),
				'not_found_in_trash' => __( 'No Enquiries found in Trash.', 'tripzzy' ),
				'parent_item_colon'  => __( 'Parent Enquiries:', 'tripzzy' ),
				'search_items'       => __( 'Search Enquiries', 'tripzzy' ),
				'singular_name'      => _x( 'Enquiry', 'post type singular name', 'tripzzy' ),
				'view_item'          => __( 'View Enquiry', 'tripzzy' ),
			);

			$args = array(
				'labels'             => $labels,
				'description'        => __( 'Description.', 'tripzzy' ),
				'public'             => false,
				'publicly_queryable' => false,
				'show_ui'            => true,
				'show_in_menu'       => 'edit.php?post_type=tripzzy_booking',
				'query_var'          => true,
				'rewrite'            => array(
					'slug'       => 'tripzzy-enquiries',
					'with_front' => true,
				),
				'capability_type'    => 'post',
				'has_archive'        => false,
				'hierarchical'       => false,
				'menu_position'      => 20,
				'supports'           => array( 'title' ),
				'menu_icon'          => 'dashicons-bank',
				'show_in_rest'       => true,
				'rest_base'          => 'enquiry',
				'priority'           => 70,
			);
			return $args;
		}
		/**
		 * Meta Box arguments.
		 * Required Method to register Metabox if filter `tripzzy_filter_meta_box_args` is used.
		 *
		 * @param int $enquiry_id Enquiry ID.
		 * @since 1.0.0
		 */
		protected static function meta_box_args( $enquiry_id ) {

			$values = MetaHelpers::get_post_meta( $enquiry_id, 'enquiry' );

			if ( ! $values || ! is_array( $values ) ) {
				$values = array();
			}
			if ( get_post_type( $enquiry_id ) !== self::$post_type ) {
				return;
			}

			$fields = EnquiryForm::get_fields(); // Fields without values.

			foreach ( $fields as $field_index => $field ) {
				if ( ! is_array( $field ) ) {
					continue;
				}

				if ( 'repeator' === $field['type'] ) {
					$repeator_fields        = $field['children'];
					$repeator_values        = isset( $values[ $field['name'] ] ) ? $values[ $field['name'] ] : array();
					$child_with_val         = self::repeator_field_values( $repeator_fields, $repeator_values );
					$field['children']      = $child_with_val;
					$fields[ $field_index ] = $field;
				} else {
					$fallback_value = isset( $field['value'] ) ? $field['value'] : '';
					$value          = isset( $values[ $field['name'] ] ) ? $values[ $field['name'] ] : $fallback_value;

					$field['value']         = $value;
					$fields[ $field_index ] = $field;
				}
			}

			$args = array(
				'trip_enquiries' => array(  // Meta Box ID.
					'title'  => __( 'Trip Enquiry', 'tripzzy' ), // Required.
					'fields' => $fields,
				),
			);
			return $args;
		}

		/**
		 * Add Field values to repeator fields.
		 *
		 * @param array $fields Repeator Fields.
		 * @param array $values Repeator Values.
		 */
		public static function repeator_field_values( $fields, $values ) {
			foreach ( $fields as $field_index => $field ) {
				if ( 'repeator' === $field['type'] ) {
					$repeator_fields        = $field['children'];
					$repeator_values        = isset( $values[ $field['name'] ] ) ? $values[ $field['name'] ] : array();
					$child_with_val         = self::repeator_field_values( $repeator_fields, $repeator_values );
					$field['children']      = $child_with_val;
					$fields[ $field_index ] = $field;
					return $fields;
				} else {
					$fallback_value = isset( $field['value'] ) ? $field['value'] : '';
					$value          = isset( $values[ $field['name'] ] ) ? $values[ $field['name'] ] : $fallback_value;

					$field['value']         = $value;
					$fields[ $field_index ] = $field;
				}
			}
			return $fields;
		}

		/**
		 * Save post meta for enquiry data.
		 *
		 * @param int $enquiry_id Enquiry ID.
		 */
		public static function save_meta( $enquiry_id ) {
			if ( ! Nonce::verify() ) {
				return;
			}
			$values = MetaHelpers::get_post_meta( $enquiry_id, 'enquiry' );
			if ( ! $values || ! is_array( $values ) ) {
				$values = array();
			}

			$fields = EnquiryForm::get_fields();
			foreach ( $fields as $field ) {
				$name = $field['name'];
				if ( isset( $_POST[ $name ] ) ) { // @codingStandardsIgnoreLine
					$values[ $name ] = sanitize_text_field( wp_unslash( $_POST[ $name ] ?? '' ) ); // @codingStandardsIgnoreLine
				}
			}
			MetaHelpers::update_post_meta( $enquiry_id, 'enquiry', $values );
		}

		/**
		 * Display Post state form trip enquiry.
		 *
		 * @param array  $states List of stated.
		 * @param object $post Post object.
		 * @return array
		 */
		public function display_post_states( $states, $post ) {
			if ( Page::is( 'enquiry', true ) ) {
				$status = $post->post_status;
				$status = 'pending' === $status ? __( 'Unread', 'tripzzy' ) : __( 'Read', 'tripzzy' );
				$states = array( $status );
			}
			return $states;
		}

		/**
		 * Make enquiry Post mark as read on post load from admin.
		 *
		 * @return void
		 */
		public function mark_as_read() {
			if ( ! is_admin() ) {
				return;
			}
			$enquiry_id = absint( $_GET['post'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			if ( get_post_type( $enquiry_id ) !== self::$post_type ) {
				return;
			}
					$post_status = get_post_status( $enquiry_id );
			if ( 'pending' === $post_status ) {
				wp_update_post(
					array(
						'ID'          => $enquiry_id,
						'post_status' => 'publish',
					)
				);
			}
		}
	}
}
