=== Tripzzy - Best Travel Engine Plugin for WordPress ===
Contributors: refreshthemes
Tags: trip, travel, tour, trip-packages, trip-booking, trip-itinerary, trip-booking-engine,trip-destinations, trip-locations, trip-maps
Requires at least: 5.8
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.0.4
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Tripzzy is a free travel booking WordPress plugin designed to help you create travel and tour packages for tour operators and travel agencies quickly and easily.
== Description ==
**Best Travel Engine for WordPress Plugin**

Tripzzy is designed to help you create and manage your travel-related content on your WordPress website. With this plugin, you can make travel itineraries, showcase your travel destinations, and even sell travel packages directly from your website.

[View Documentation](https://docs.wptripzzy.com/) | [View Demo](https://demo.wptripzzy.com/)

=Features=
1. **Trip packages** - Create and manage an unlimited number of packages as per your trip needs.
2. **Trip dates** - Create and manage fixed and recurring trip dates.
3. **Trip booking system** - Simple trip booking system and customizable booking form.
4. **Discount coupon** - Tripzzy allows you to add coupons for the trips.
5. **Display trip infos** - Display additional infos according to trip.
6. **Trip itineraries** - Easily add and display the trip itineraries.
7. **Image gallery** - Add and display the trip gallery.
8. **Trip map** - Display Google map or iframe map for each trip.
9. **Trip difficulties** - Display the trip difficulty level for the users.
10. **Trip Reviews** - Customer can add their reviews about the trip.
11. **Search form shortcode** - Search Shortcodes help find the desired trips as per your search parameters.
12. **Trip Filters** - Use the existing search filters or create custom filters to let your customers find the matching trip.
13. **Enquiry form** - Custom can easily send their enquiry for the trips by filling enquiry form. You can now get more enquiries about your trip packages.
14. **User Dashboard** - User Dashboard helps you to find your bookings, wishlists, reviews, etc.
15. **Translation ready** - The plugin is fully translation ready. So feel free to translate your website into your own or any other language.

If you need help with the Tripzzy plugin, please visit the our support forum on the WordPress plugin repository or the official website. We're always happy to help!

== Third Party Libraries ==

Font Awesome - Toolkit to display icons.
Copyright 2022 Fonticons, Inc.
Version: 6.2.0
License: https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License)
Source: https://fontawesome.com

GMap - Library to display google map.
Copyright (c) 2015 Michele Bertoli
Version: 1.9
License: Licensed under the MIT license - https://github.com/MicheleBertoli/react-gmaps/blob/master/LICENSE
Source: https://github.com/MicheleBertoli/react-gmaps

React Date Picker - UI component that allows you to select a date or a range of dates.
Copyright (c) 2014-2023 HackerOne Inc and individual contributors
Version: 4.11.0
License: Licensed under the MIT license - https://github.com/Hacker0x01/react-datepicker/blob/main/LICENSE
Source: https://github.com/Hacker0x01/react-datepicker

React Select - Library for building custom, accessible, and flexible select inputs for React applications.
Copyright (c) 2022 Jed Watson
Version: 5.4.0
License: Licensed under the MIT license - https://github.com/JedWatson/react-select/blob/master/LICENSE
Source: https://github.com/JedWatson/react-select

Rrule - It is used to define recurring events or schedules in a calendar.
Copyright 2010, Jakub Roztocil <jakub@roztocil.name> and Lars Schöning
Version: 2.7.1
License: Licensed under the BSD-3-Clause - https://github.com/jkbrzt/rrule/blob/master/LICENCE
Source: https://github.com/jkbrzt/rrule

Paypal js - Render Paypal Payment button to checkout.
Copyright 2020 PayPal
License: Apache License - https://github.com/paypal/paypal-js/blob/main/LICENSE
Source: https://github.com/paypal/paypal-js

React Sortablejs - Library to sort html element.
Copyright (c) 2020 All contributors to react-sortablejs
Version: 6.1.4
License: Licensed under the MIT license - https://github.com/SortableJS/react-sortablejs/blob/master/LICENSE
Source: https://github.com/SortableJS/react-sortablejs

== Installation ==
= Using The WordPress Dashboard =
* Navigate to the 'Add New' on the plugins dashboard page.
* Search for Tripzzy.
* Click Install Now.
* Activate the plugin on the Plugin dashboard page.

= Uploading in WordPress Dashboard =
* Download [tripzzy.zip](https://wordpress.org/plugins/tripzzy)
* Navigate to the 'Add New' on the plugins dashboard page.
* Navigate to the 'Upload' section.
* Select tripzzy.zip from your computer.
* Click 'Install Now'.
* Activate the plugin on the Plugin dashboard page.

= Using FTP =
* Download [tripzzy.zip](https://wordpress.org/plugins/tripzzy)
* Extract the tripzzy directory to your computer
* Upload the tripzzy directory to the /wp-content/plugins/ directory
* Activate the plugin in the Plugin dashboard.


== Screenshots ==
1. Frontend : Archive Page
2. Frontend : Trip
3. Frontend : Itineraries
4. Frontend : Availability
5. Frontend : Checkout
6. Frontend : Trip Search form
7. Admin : New Trip
8. Admin : Trip Settings
9. Admin : Trip Infos Settings
10. Admin : Forms

== Changelog ==

= 1.0.4 - 1st January 2024 =
* Tweak: Added paragraph support in itineraries description.
* Tweak: Removed Price category, trip includes and trip excludes taxonomies from trip info list.
* Fix: Removed input fields displaying in booking email.
* Fix: Form validation added for PayPal Payment on checkout.
* Fix: Settings reset not resetting trip info.
* Fix: Minor layout issues.

= 1.0.3 - 25th December 2023 =
* Fix: render_class warning on activation.
* Fix: Search form field not displaying in sub site setup.
* Added Default thumbnail on taxonomy items block if thumbnail image not selected.

= 1.0.2 - 14th December 2023 =
* New: Added Sticky Tab in trip detail page and its settings.
* New: Added age requirement as default trip info field.
* Tweak: Itinerary schedule (time and title) can be added in one step.
* Tweak: Updated Smooth Scroll scripts.
* Tweak: Updated Close icon in all admin forms and panels.
* Fix: Hide more photos link if less than one image in gallery.
* Fix: Hide discount % if sale price higher than trip price.
* Updated the layout of trip category blocks
* Tripzzy Welcome Pointer displayed in Tripzzy Homepage too.


[See changelog for all versions](https://plugins.svn.wordpress.org/tripzzy/trunk/changelog.txt).
